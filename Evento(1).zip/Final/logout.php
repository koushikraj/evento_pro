<?php
error_reporting(0);
session_start();
$_SESSION['flag']="logout";
$_SESSION['User']=null;
header("Cache-Control: no-cache, no-store, must-revalidate"); // HTTP 1.1.
header("Pragma: no-cache"); // HTTP 1.0.
header("Expires: 0"); // Proxies.
header("Location: index.php");


?>