<!DOCTYPE html>
<html class=" js rgba multiplebgs backgroundsize borderradius boxshadow textshadow opacity cssgradients csstransitions generatedcontent js rgba multiplebgs backgroundsize borderradius boxshadow textshadow opacity cssgradients csstransitions generatedcontent" lang="en"><!--<![endif]--><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Evento</title>

<meta name="robots" content="noindex,follow">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<link  href="./docs/css/datepicker.css" rel="stylesheet">
<script src="./docs/js/datepicker.js"></script>
<link  href="notify.css" rel="stylesheet">
<link rel="icon" href="favicon.ico" type="image/x-icon" />

	<script type="text/javascript">
		/* <![CDATA[ */
		function addLoadEvent(func) {
			var oldonload = window.onload;
			if (typeof window.onload != 'function') {
				window.onload = func;
			} else {
				window.onload = function () {
					oldonload();
					func();
				}
			}
		}
		/* ]]> */
	</script>
	<script>
$(document).ready(function(){

	$('[data-toggle="datepicker"]').datepicker({
		format: 'yyyy-mm-dd'
	});
	$('[data-toggle="datepicker"]').on('pick.datepicker', function (e) {
		
		$('#month').val((e.date.getMonth()+1).toString());
		$('#year').val(e.date.getFullYear().toString());
		$('#day').val(e.date.getDate().toString());
		$('form#mon').submit();
	});
});


</script>
	<link rel="stylesheet" id="all-css-0" href="./eventoCSS/saved_resource_week.css" type="text/css" media="all">


<link rel="stylesheet" id="all-css-6" href="./eventoCSS/saved_resource(1).css" type="text/css" media="all">

<link href="https://fonts.googleapis.com/css?family=Cutive" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet" type="text/css">
<link rel="stylesheet" id="all-css-8" href="./eventoCSS/saved_resource(2).css" type="text/css" media="all">
<script type="text/javascript">
/* <![CDATA[ */
var LoggedOutFollow = {"invalid_email":"Your subscription did not succeed, please try again with a valid email address."};
/* ]]> */
</script>
<script type="text/javascript" src="./eventoCSS/saved_resource(3).js"></script>

<!--[if lt IE 8]>
<link rel='stylesheet' id='highlander-comments-ie7-css'  href='https://s1.wp.com/wp-content/mu-plugins/highlander-comments/style-ie7.css?m=1351637563h&#038;ver=20110606' type='text/css' media='all' />
<![endif]-->

 
<meta name="generator" content="WordPress.com">



<!-- Jetpack Open Graph Tags -->
<meta property="og:type" content="article">
<meta property="og:title" content="Calendar">
<meta property="og:url" content="https://eventbritevenuedemo.wordpress.com/calendar/">
<meta property="og:description" content="Visit the post for more.">
<meta property="article:published_time" content="2013-09-10T19:46:38+00:00">
<meta property="article:modified_time" content="2013-09-10T19:46:38+00:00">
<meta property="og:site_name" content="Eventbrite Multi">
<meta property="og:image" content="https://s0.wp.com/i/blank.jpg">
<meta property="og:locale" content="en_US">
<meta name="twitter:site" content="@wordpressdotcom">
<meta name="twitter:card" content="summary">
<meta name="twitter:description" content="Visit the post for more.">
<meta property="fb:app_id" content="249643311490">
<meta property="article:publisher" content="https://www.facebook.com/WordPresscom">







		<style type="text/css">
			.recentcomments a {
				display: inline !important;
				padding: 0 !important;
				margin: 0 !important;
			}

			table.recentcommentsavatartop img.avatar, table.recentcommentsavatarend img.avatar {
				border: 0px;
				margin: 0;
			}

			table.recentcommentsavatartop a, table.recentcommentsavatarend a {
				border: 0px !important;
				background-color: transparent !important;
			}

			td.recentcommentsavatarend, td.recentcommentsavatartop {
				padding: 0px 0px 1px 0px;
				margin: 0px;
			}

			td.recentcommentstextend {
				border: none !important;
				padding: 0px 0px 2px 10px;
			}

			.rtl td.recentcommentstextend {
				padding: 0px 10px 2px 0px;
			}

			td.recentcommentstexttop {
				border: none;
				padding: 0px 0px 0px 10px;
			}

			.rtl td.recentcommentstexttop {
				padding: 0px 10px 0px 0px; 
			}
		</style>
		<meta name="application-name" content="Eventbrite Multi"><meta name="msapplication-window" content="width=device-width;height=device-height"><meta name="msapplication-tooltip" content="Connect to Eventbrite with your WordPress.com theme"><meta name="msapplication-task" content="name=Subscribe;action-uri=https://eventbritevenuedemo.wordpress.com/feed/;icon-uri=https://s2.wp.com/i/favicon.ico"><meta name="msapplication-task" content="name=Sign up for a free blog;action-uri=http://wordpress.com/signup/;icon-uri=https://s2.wp.com/i/favicon.ico"><meta name="msapplication-task" content="name=WordPress.com Support;action-uri=http://support.wordpress.com/;icon-uri=https://s2.wp.com/i/favicon.ico"><meta name="msapplication-task" content="name=WordPress.com Forums;action-uri=http://forums.wordpress.com/;icon-uri=https://s2.wp.com/i/favicon.ico"><meta name="title" content="Calendar | Eventbrite Multi on WordPress.com">
<meta name="description" content="Connect to Eventbrite with your WordPress.com theme">
		<style type="text/css">
					header .logo-text h1,
			header .logo-text h5 {
				color: #fff;
			}
			#matter{
				color:#e77e23;
			}
			#plus{
				float:right;
				width:12px;
				background-color:#607D8B;
				color:#FFF;
				text-align:center;
				cursor:pointer;
				//font-size:30px;
				border-radius:20px;
				
			}
			#event_block:hover{
				text-decoration: underline;
				color:#BF360C;
				cursor:pointer;
				
			}
				</style>
				<style type="text/css" id="eventbrite-header-css">
		header[role=banner] {
			background: url(cropped-cropped-ola-bread-tray-1.jpg) top center no-repeat;
			background-size: cover;
		}
		</style>
		<style type="text/css" id="custom-background-css">
body.custom-background { background-image: url('bg-main.png'); background-repeat: repeat; background-position: top left; background-attachment: scroll; }
</style>
<style type="text/css" id="syntaxhighlighteranchor"></style>
			<style id="demo-site-activation">
				#infinite-footer {
					display: none !important;
				}

				@media screen and (max-width: 600px) {
					.demosite-activate {
						position: absolute;
					}
				}
			</style>
					<style id="demo-site-activation-logged-out">
				
				@media screen and (max-width: 620px) {
					html {
						margin-top: 100px !important;
					}
				}
				@media screen and (max-width: 600px) {
					.demosite-activate {
						position: absolute;
					}
				}
			</style>
		</head>

<body class="page page-id-108 page-template-default custom-background mp6 customizer-styles-applied template-calendar highlander-enabled highlander-light demo-site" data-pinterest-extension-installed="cr1.39.1">
		<header role="banner">
		<div class="container">
			<div class="logo-row">
												<a class="logo-text">
					<h1 style="font-family:Cutive;">Evento</h1>
					<h5 style="font-family:Raleway;">Connect to Evento with your Webmail facilities</h5>
					<br>
				</a>
			</div>
		</div>
	</header>
	<br>

	<section role="main" class="main-container">
		<div id="site-container" class="container">
			<nav class="menu">
			<ul id="menu-main-menu" class="menu">
	<li id="menu-item-112" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-108 current_page_item menu-item-112"><a>All Events</a>
		<ul class="sub-menu">
		<li id="menu-item-122" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-122"><a href="month.php">Month View</a></li>
		<li id="menu-item-117" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-117"><a href="week.php">Week View</a></li>
		<li id="menu-item-116" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-116"><a href="day.php">Day View</a></li>
		</ul>
	</li>
	<li id="menu-item-151" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-151"><a>My Schedule</a>
		<ul class="sub-menu">
		<li id="menu-item-122" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-122"><a href="mymonth.php">Month View</a></li>
		<li id="menu-item-117" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-117"><a href="myweek.php">Week View</a></li>
		<li id="menu-item-116" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-116"><a href="myday.php">Day View</a></li>
		</ul>
	</li>
	<li id="menu-item-111" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-111"><a href="myevents.php">My Events</a></li>
	<li id="menu-item-114" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-114"><a href="venue.php">Venues</a>

	</li>
	<li id="menu-item-113" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-113"><a href="compose.php">Compose</a></li>
	<li id="menu-item-113" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-113" style="float:right; border-right: 1px solid #666;"><a href="logout.php"><img src="logout.png"></a></li>
	<li id="menu-item-113" class="dropdown" style="float:right;"><a onclick="myFunction()" class="dropbtn"><span onclick="myFunction()"><img src="notification.png"></a></li>
	<li id="menu-item-113" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-113" style="float:right; border-right: 1px solid #666;"><a href="search.php"><img src="Search.png"></span></a></li>
	</ul>
	</nav>
	
	<div id="myDropdown" class="dropdown-content">
    <br />
	<p style="text-align:center;">NOTIFICATIONS</p>
	<hr style="margin:6px;border-top: 1px solid black;"/>
	<?php
		error_reporting(0);
		session_start();
		
		mysql_connect("localhost","bora.cs14","bora@678") or die("Cannot connect to databse");
		mysql_select_db($_SESSION['User']) or die("Cannot find database");
		$query = "SELECT * FROM notifications ORDER BY Sno DESC";
		$result = mysql_query($query) or die('cannot get results!');
		$notify = array();

		while($row = mysql_fetch_assoc($result)) {
			$notify[] = $row['Data'];
		}
		$flag=1;
	foreach($notify as $data){
		if($flag){
				echo '<b id="grey">'.$data.'</b>';
				$flag=!$flag;
		}
		else{
			  echo '<b id="white" >'.$data.'</b>';
			  $flag=!$flag;
		}
		
	}
		
	?>
	</div>
	<script>
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {

    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>


<div class="row">
	<div class="span12">

<?php
if($_SESSION['User']){
//error_reporting(0);
$month = (int) (isset($_GET['month']) ? $_GET['month'] : date('m'));
$year = (int)  (isset($_GET['year']) ? $_GET['year'] : date('Y'));
$day = (int)  (isset($_GET['day']) ? $_GET['day'] : date('d'));


$weekPos = date('w',mktime(0,0,0,$month,$day,$year));

$prev_mon_days = date('t',mktime(0,0,0,($month!=1)?$month-1:12,1,($month==1)?$year-1:$year));
$this_mon_days = date('t',mktime(0,0,0,$month,1,$year));
if($day-$weekPos<0)
$initial =  (($month==1)?$year-1: $year) ."-".sprintf("%02d",(($month!=1)?$month-1:12))."-". sprintf("%02d",($day-$weekPos+$prev_mon_days))  ; 
else
$initial =  $year ."-".sprintf("%02d",$month)."-".sprintf("%02d",($day-$weekPos)) ;

$final = ($day+6-$weekPos>$this_mon_days) ? (  (($month==12)?$year+1:$year)."-".(($month!=12)?$month+1:1)."-".($day+6-$weekPos-$this_mon_days) ): ( $year."-".$month."-".($day+6-$weekPos) );

/*************************To get Paths***********************************/
mysql_connect("localhost","bora.cs14","bora@678") or die("Cannot connect to databse");
mysql_select_db($_SESSION['User']) or die("Cannot find database");
$query = "SELECT Pointer FROM all_events WHERE Intersted='1'";
$result = mysql_query($query) or die('cannot get results!');
$paths = array();

while($row = mysql_fetch_assoc($result)) {
	$paths[] = $row['Pointer'];
}
$pathstr = implode(",",$paths);

/****************************************************************************/

$mon1 = explode("-",$initial)[1];
$mon2 = explode("-",$final)[1];

$year1 = explode("-",$initial)[0];
$year2 = explode("-",$final)[0];
/****************************************************************************/


/**************************To get non rec events from main********************************/

mysql_select_db("main") or die("Cannot find database");
$events = array();	


$query = "SELECT * FROM all_events WHERE (Month='$mon1' OR Month='$mon2') AND (Year='$year1' OR Year='$year2') AND Sno in ($pathstr) AND Recurring='no'";

$result = mysql_query($query) or die('cannot get results!');
while($row = mysql_fetch_assoc($result)) {
	
	//echo $row['Year']."-".sprintf("%02d",$row['Month'])."-".sprintf("%02d",$row['Day']) ;
	$events[  $row['Year']."-".sprintf("%02d",$row['Month'])."-".sprintf("%02d",$row['Day'])  ][] = $row;

}

/****************************************************************************/

/**************************To fetch recurring events***************************************/

$query = "SELECT * FROM all_events WHERE Sno in ($pathstr) AND Recurring<>'no'" ;
$result = mysql_query($query) or die('cannot get results!');
$recEvents = array();

while($row = mysql_fetch_assoc($result)){
	$recEvents[]= $row;
}

foreach ($recEvents as $row){
	
	$start = $row['Year']."-".sprintf("%02d",$row['Month'])."-".sprintf("%02d",$row['Day']);
	
	$end = $row['EndDate'];
	$rec = $row['Recurring'];
	
	/*Day recurring*/
	if(explode("_",$rec)[0]=="Day"){
		
		$n = " + ".explode("_",$rec)[1]." days";
		$curr = $start;
		$end = date('Y-m-d', strtotime($end.$n));
		while(strtotime($curr)<strtotime($end)){
			if(explode("-",$curr)[0]==$year1  && explode("-",$curr)[1]==sprintf("%02d",$mon1)){
					$events[$year1."-".sprintf("%02d",$mon1)."-".explode("-",$curr)[2]][] = $row;
			}
			elseif(explode("-",$curr)[0]==$year1  && explode("-",$curr)[1]==sprintf("%02d",$mon2)){
					$events[$year1."-".sprintf("%02d",$mon2)."-".explode("-",$curr)[2]][] = $row;
			}
			elseif(explode("-",$curr)[0]==$year2  && explode("-",$curr)[1]==sprintf("%02d",$mon2)){
					$events[$year2."-".sprintf("%02d",$mon2)."-".explode("-",$curr)[2]][] = $row;
			}
			$curr = date('Y-m-d', strtotime($curr.$n));
		}
	}
	/*Week recurring*/
	elseif(explode("_",$rec)[0]=="Week"){
		
		$n = " + 1 days";
		$curr = $start;
		$end = date('Y-m-d', strtotime($end.$n));

		while(strtotime($curr)<strtotime($end)){
			if(explode("-",$curr)[0]==$year1 && explode("-",$curr)[1]==sprintf("%02d",$mon1) && ''.date("w",strtotime($curr))==''.explode("_",$rec)[1]){
					$events[$year1."-".sprintf("%02d",$mon1)."-".explode("-",$curr)[2]][] = $row;
			}
			elseif(explode("-",$curr)[0]==$year1 && explode("-",$curr)[1]==sprintf("%02d",$mon2) && ''.date("w",strtotime($curr))==''.explode("_",$rec)[1]){
					$events[$year1."-".sprintf("%02d",$mon2)."-".explode("-",$curr)[2]][] = $row;
			}
			elseif(explode("-",$curr)[0]==$year2 && explode("-",$curr)[1]==sprintf("%02d",$mon2) && ''.date("w",strtotime($curr))==''.explode("_",$rec)[1]){
					$events[$year2."-".sprintf("%02d",$mon2)."-".explode("-",$curr)[2]][] = $row;
			}
			$curr = date('Y-m-d', strtotime($curr.$n));
		}
	}
	/*Month recurring*/
	elseif(explode("_",$rec)[0]=="Month"){
		
		$n = " + 1 days";
		$curr = $start;
		$end = date('Y-m-d', strtotime($end.$n));

		while(strtotime($curr)<strtotime($end)){
			if(explode("-",$curr)[0]==$year1 && explode("-",$curr)[1]==sprintf("%02d",$mon1) && ''.explode("-",$curr)[2]==''.explode("_",$rec)[1]){
					$events[$year1."-".sprintf("%02d",$mon1)."-".explode("-",$curr)[2]][] = $row;
			}
			elseif(explode("-",$curr)[0]==$year1 && explode("-",$curr)[1]==sprintf("%02d",$mon2) && ''.explode("-",$curr)[2]==''.explode("_",$rec)[1]){
					$events[$year1."-".sprintf("%02d",$mon2)."-".explode("-",$curr)[2]][] = $row;
			}
			elseif(explode("-",$curr)[0]==$year2 && explode("-",$curr)[1]==sprintf("%02d",$mon2) && ''.explode("-",$curr)[2]==''.explode("_",$rec)[1]){
					$events[$year2."-".sprintf("%02d",$mon2)."-".explode("-",$curr)[2]][] = $row;
			}
			$curr = date('Y-m-d', strtotime($curr.$n));
		}
	}
	/*Year recurring*/
	elseif(explode("_",$rec)[0]=="Year"){
		$dayY = explode("_",$rec)[1];
		$monY = explode("_",$rec)[2];
		$n = " + 1 days";
		$curr = $start;
		$end = date('Y-m-d', strtotime($end.$n));

		while(strtotime($curr)<strtotime($end)){
			if(explode("-",$curr)[0]==$year1 && explode("-",$curr)[1]==sprintf("%02d",$mon1) && ''.explode("-",$curr)[1]==$monY && ''.explode("-",$curr)[2]==$dayY){
					$events[$year1."-".sprintf("%02d",$mon1)."-".explode("-",$curr)[2]][] = $row;
			}
			elseif(explode("-",$curr)[0]==$year1 && explode("-",$curr)[1]==sprintf("%02d",$mon2) && ''.explode("-",$curr)[1]==$monY && ''.explode("-",$curr)[2]==$dayY){
					$events[$year1."-".sprintf("%02d",$mon2)."-".explode("-",$curr)[2]][] = $row;
			}
			elseif(explode("-",$curr)[0]==$year2 && explode("-",$curr)[1]==sprintf("%02d",$mon2) && ''.explode("-",$curr)[1]==$monY && ''.explode("-",$curr)[2]==$dayY){
					$events[$year2."-".sprintf("%02d",$mon2)."-".explode("-",$curr)[2]][] = $row;
			}
			$curr = date('Y-m-d', strtotime($curr.$n));
		}
	}
	
}

/****************************************************************************/


/**************************To get events from my schedule********************************/

mysql_select_db($_SESSION['User']) or die("Cannot find database");

$query = "SELECT * FROM my_schedule WHERE (Month='$mon1' OR Month='$mon2') AND (Year='$year1' OR Year='$year2') AND Recurring='no'";
$result = mysql_query($query) or die('cannot get results!'.mysql_error());
while($row = mysql_fetch_assoc($result)) {

		$e[  $row['Year']."-".sprintf("%02d",$row['Month'])."-".sprintf("%02d",$row['Day'])  ][] = $row;

	//echo $row['Year']."-".sprintf("%02d",$row['Month'])."-".sprintf("%02d",$row['Day']) ;
	$events[  $row['Year']."-".sprintf("%02d",$row['Month'])."-".sprintf("%02d",$row['Day'])  ][] = $row;

}

/****************************************************************************/

/**************************To fetch recurring events from my schedule***************************************/

$query = "SELECT * FROM my_schedule WHERE Recurring<>'no'" ;
$result = mysql_query($query) or die('cannot get results!');
$recEvents = array();
while($row = mysql_fetch_assoc($result)){
	$recEvents[]= $row;
}

foreach ($recEvents as $row){
	
	$start = $row['Year']."-".sprintf("%02d",$row['Month'])."-".sprintf("%02d",$row['Day']);
	
	$end = $row['EndDate'];
	$rec = $row['Recurring'];
	
	/*Day recurring*/
	if(explode("_",$rec)[0]=="Day"){
		
		$n = " + ".explode("_",$rec)[1]." days";
		$curr = $start;
		$end = date('Y-m-d', strtotime($end.$n));
		while(strtotime($curr)<strtotime($end)){
			if(explode("-",$curr)[0]==$year1  && explode("-",$curr)[1]==sprintf("%02d",$mon1)){
					$events[$year1."-".sprintf("%02d",$mon1)."-".explode("-",$curr)[2]][] = $row;

			}
			elseif(explode("-",$curr)[0]==$year1  && explode("-",$curr)[1]==sprintf("%02d",$mon2)){
					$events[$year1."-".sprintf("%02d",$mon2)."-".explode("-",$curr)[2]][] = $row;

			}
			elseif(explode("-",$curr)[0]==$year2  && explode("-",$curr)[1]==sprintf("%02d",$mon2)){
					$events[$year2."-".sprintf("%02d",$mon2)."-".explode("-",$curr)[2]][] = $row;
			}
			$curr = date('Y-m-d', strtotime($curr.$n));
		}
	}
	/*Week recurring*/
	elseif(explode("_",$rec)[0]=="Week"){
		
		$n = " + 1 days";
		$curr = $start;
		$end = date('Y-m-d', strtotime($end.$n));

		while(strtotime($curr)<strtotime($end)){
			if(explode("-",$curr)[0]==$year1 && explode("-",$curr)[1]==sprintf("%02d",$mon1) && ''.date("w",strtotime($curr))==''.explode("_",$rec)[1]){
					$events[$year1."-".sprintf("%02d",$mon1)."-".explode("-",$curr)[2]][] = $row;
			}
			elseif(explode("-",$curr)[0]==$year1 && explode("-",$curr)[1]==sprintf("%02d",$mon2) && ''.date("w",strtotime($curr))==''.explode("_",$rec)[1]){
					$events[$year1."-".sprintf("%02d",$mon2)."-".explode("-",$curr)[2]][] = $row;
			}
			elseif(explode("-",$curr)[0]==$year2 && explode("-",$curr)[1]==sprintf("%02d",$mon2) && ''.date("w",strtotime($curr))==''.explode("_",$rec)[1]){
					$events[$year2."-".sprintf("%02d",$mon2)."-".explode("-",$curr)[2]][] = $row;
			}
			$curr = date('Y-m-d', strtotime($curr.$n));
		}
	}
	/*Month recurring*/
	elseif(explode("_",$rec)[0]=="Month"){
		
		$n = " + 1 days";
		$curr = $start;
		$end = date('Y-m-d', strtotime($end.$n));

		while(strtotime($curr)<strtotime($end)){
			if(explode("-",$curr)[0]==$year1 && explode("-",$curr)[1]==sprintf("%02d",$mon1) && ''.explode("-",$curr)[2]==''.explode("_",$rec)[1]){
					$events[$year1."-".sprintf("%02d",$mon1)."-".explode("-",$curr)[2]][] = $row;
			}
			elseif(explode("-",$curr)[0]==$year1 && explode("-",$curr)[1]==sprintf("%02d",$mon2) && ''.explode("-",$curr)[2]==''.explode("_",$rec)[1]){
					$events[$year1."-".sprintf("%02d",$mon2)."-".explode("-",$curr)[2]][] = $row;
			}
			elseif(explode("-",$curr)[0]==$year2 && explode("-",$curr)[1]==sprintf("%02d",$mon2) && ''.explode("-",$curr)[2]==''.explode("_",$rec)[1]){
					$events[$year2."-".sprintf("%02d",$mon2)."-".explode("-",$curr)[2]][] = $row;
			}
			$curr = date('Y-m-d', strtotime($curr.$n));
		}
	}
	/*Year recurring*/
	elseif(explode("_",$rec)[0]=="Year"){
		$dayY = explode("_",$rec)[1];
		$monY = explode("_",$rec)[2];
		$n = " + 1 days";
		$curr = $start;
		$end = date('Y-m-d', strtotime($end.$n));

		while(strtotime($curr)<strtotime($end)){
			if(explode("-",$curr)[0]==$year1 && explode("-",$curr)[1]==sprintf("%02d",$mon1) && ''.explode("-",$curr)[1]==$monY && ''.explode("-",$curr)[2]==$dayY){
					$events[$year1."-".sprintf("%02d",$mon1)."-".explode("-",$curr)[2]][] = $row;
			}
			elseif(explode("-",$curr)[0]==$year1 && explode("-",$curr)[1]==sprintf("%02d",$mon2) && ''.explode("-",$curr)[1]==$monY && ''.explode("-",$curr)[2]==$dayY){
					$events[$year1."-".sprintf("%02d",$mon2)."-".explode("-",$curr)[2]][] = $row;
			}
			elseif(explode("-",$curr)[0]==$year2 && explode("-",$curr)[1]==sprintf("%02d",$mon2) && ''.explode("-",$curr)[1]==$monY && ''.explode("-",$curr)[2]==$dayY){
					$events[$year2."-".sprintf("%02d",$mon2)."-".explode("-",$curr)[2]][] = $row;
			}
			$curr = date('Y-m-d', strtotime($curr.$n));
		}
	}
	
}

/****************************************************************************/

	


$next = explode("-",date('Y-m-d',strtotime($initial.' + 7 days')));
$prev = explode("-",date('Y-m-d',strtotime($initial.' - 7 days')));


	echo '<table class="page-calendar">';

	echo '<thead>
		<tr class="navigation">
			<th class="prev-month"><a href="?month='.$prev[1].'&year='.$prev[0].'&day='.$prev[2].'">‹Prev Week	</a></th>
			<th colspan="6" class="current-month"><input id="currMon" type="text" style="border:none; box-shadow:none; font-family:cutive; text-transform:uppercase; font-size:0.9em; font-weight:bold; background-color:white; cursor:pointer " readonly="readonly" data-toggle="datepicker" value="'.date('F',mktime(0,0,0,$month,1,$year)).' '.$year.'"></th>
			<th class="next-month"><a href="?month='.$next[1].'&year='.$next[0].'&day='.$next[2].'">Next Week›</a></th>
		</tr></thead></table>
		
		<table class="page-calendar">
		<thead>
		<tr class="weekdays">
		<th style="width:50px;//background-color:white"></th>
		<th>Sunday<br />'.date('d-m-Y',strtotime($initial.' + 0 days')).'</th>
		<th>Monday<br />'.date('d-m-Y',strtotime($initial.' + 1 days')).'</th>
		<th>Tuesday<br />'.date('d-m-Y',strtotime($initial.' + 2 days')).'</th>
		<th>Wednesday<br />'.date('d-m-Y',strtotime($initial.' + 3 days')).'</th>
		<th>Thursday<br />'.date('d-m-Y',strtotime($initial.' + 4 days')).'</th>
		<th>Friday<br />'.date('d-m-Y',strtotime($initial.' + 5 days')).'</th>
		<th>Saturday<br />'.date('d-m-Y',strtotime($initial.' + 6 days')).'</th>
					</tr>
	</thead></table> 
	
	<div style="overflow-y:scroll;height:500px;">
	<table class="page-calendar">
	<tbody>';
	
	
	$content="";
for($i=0;$i<=23;$i++){
	$content.='<tr>';
	$tempIn = $initial;
	$content.='<td style="width:20px; text-align:center; border:none;padding-top:20px" >'.$i.':00</td>';
	for( $j=0;$j<7;$j++){
		if(isset($events[$tempIn])){
			$content.='<td class="day">
			<span class="date" title="">
			<span id="plus" onclick="redirect(\''.$tempIn.'\','.$i.')">+</span>
			</span>
			<div id="matter" class="day-content">';
			
			
			$content.='<ul>';
			foreach($events[$tempIn] as $event){
				if(explode(":",$event['StartTime'])[0]==$i){
					$content.='<li>';
				
					$content.='<div id="event_block" onclick="';
				
				if(isset($event['Count']))
					$content.= 'event1('.$event['Sno'].')';
				else
					$content.= 'event2('.$event['Sno'].')';
				
				
				$content.='" >'.$event['Title'].'</div>';
			}
				$content.='</li>';
			}
			$content.='</ul></div></td>';
		}
		else
			$content.='<td class="day"><span class="date" title=""><span id="plus" onclick="redirect(\''.$tempIn.'\','.$i.')">+</span></span><div id="matter" class="day-content"><ul></ul></td></div>';
		
		$tempIn = date('Y-m-d', strtotime($tempIn.' + 1 days'));
	}
	$content.='</tr>';
}

$content.='</div></table></div>';
echo $content;
echo '<br /><br />';
echo '<script>


function redirect(a,b){
	var arr = a.split("-");
	location.href = "create.php?day="+arr[2]+"&month="+arr[1]+"&year="+arr[0]+"&time="+b;
}

function event1(a){
	
	location.href = "event.php?id="+a;
}


function event2(a){
	
	location.href = "myevent.php?id="+a;
}

</script>

<form id="mon" action="myweek.php" method="get">
<input name="month" id="month" type="hidden">
<input name="year" id="year" type="hidden">
<input name="day" id="day" type="hidden">
</form>



';	

}
?>

</div>
</div>
	</div>
</section>
<footer class="site-footer row" role="contentinfo">
	<div class="container">
		<div class="pull-right"><ul id="menu-footer-menu" class="menu"><li id="menu-item-123" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-123"><a href="#">All Events</a></li>
<li id="menu-item-124" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-108 current_page_item menu-item-124"><a href="about.html">about</a></li>
</ul></div>		<p>
			<a href="#">Blog at IIT Patna</a>
			Theme: Evento Venue by <a rel="designer" class="designer-link" href="#">Platform @Btech14</a>.		</p>
		<p>
			<a class="wordpress-link" href="#">Webmail teamed up with Evento</a>
		</p>
	</div>
</footer>
</body></html>
