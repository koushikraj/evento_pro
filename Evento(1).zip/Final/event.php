<?php
error_reporting(0);
session_start();
//$_SESSION['User']="bora.cs14";
if($_SESSION['User']!=null){
$id = $_GET['id'];
mysql_connect("localhost","bora.cs14","bora@678") or die("Cannot connect to databse");

/************Validate**************/
mysql_select_db($_SESSION['User']) or die("Cannot find database");
$query = "SELECT * FROM all_events WHERE Pointer='$id'";
$result = mysql_query($query) or die('cannot get results!');
if(mysql_num_rows($result)==0)
	die('Content not available');
/***********************************/
mysql_select_db("main") or die("Cannot find database");

$query = "SELECT * FROM all_events WHERE Sno='$id'";

$result = mysql_query($query) or die('cannot get results!');
$details = mysql_fetch_array($result);
if(!isset($_POST['intersted'])){
mysql_select_db($_SESSION['User']) or die("Cannot find database");
		$query = "SELECT * FROM all_events WHERE Pointer='$id'";
		$result = mysql_query($query) or die('cannot get results!');
		$row =  mysql_fetch_assoc($result);
		$interested =$row['Intersted'];
		
		if($interested==0){
				$printVar = "Interested";
		}
		else{
				$printVar = "Not Interested";			
		}
}

if(isset($_POST['interested'])){
	
	
	mysql_select_db($_SESSION['User']) or die("Cannot find database");
		$query = "SELECT * FROM all_events WHERE Pointer='$id'";
		$result = mysql_query($query) or die('cannot get results!');
		$row = mysql_fetch_assoc($result);
		$interested = $row['Intersted'];
		
		if($interested==0){
				$query = "UPDATE all_events SET Intersted='1' WHERE Pointer='$id'";
				$result = mysql_query($query) or die('cannot get results!');
				$printVar = "Not Interested";
				mysql_select_db("main") or die("Cannot find database");

				$query = "UPDATE all_events SET Count=".($details['Count']+1)." WHERE Sno='$id'";
				$result = mysql_query($query) or die('cannot update!'.mysql_error());
		}
		else{
				$query = "UPDATE all_events SET Intersted='0' WHERE Pointer='$id'";
				$result = mysql_query($query) or die('cannot get results!');

				$printVar = "Interested";
				mysql_select_db("main") or die("Cannot find database");

				$query = "UPDATE all_events SET Count=".($details['Count']-1)." WHERE Sno='$id'";
				$result = mysql_query($query) or die('cannot update!'.mysql_error());
			
		}
		

}
}
?>


<html lang="en" class=""><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="https://calendar622.wordpress.com/xmlrpc.php">
<title>Evento</title>
<link rel="alternate" type="application/rss+xml" title="Evento » Feed" href="https://calendar622.wordpress.com/feed/">
<link rel="alternate" type="application/rss+xml" title="Evento » Comments Feed" href="https://calendar622.wordpress.com/comments/feed/">
	<link rel="icon" href="favicon.ico" type="image/x-icon" />

	<script type="text/javascript">
		/* <![CDATA[ */
		function addLoadEvent(func) {
			var oldonload = window.onload;
			if (typeof window.onload != 'function') {
				window.onload = func;
			} else {
				window.onload = function () {
					oldonload();
					func();
				}
			}
		}
		/* ]]> */
	</script>
	<link rel="stylesheet" id="all-css-0" href="./eventPageCSS/saved_resource.css" type="text/css" media="all">
<link rel="stylesheet" id="sela-fonts-css" href="./eventPageCSS/css.css" type="text/css" media="all">
<link rel="stylesheet" id="all-css-2" href="./eventPageCSS/saved_resource(1).css" type="text/css" media="all">
<link rel="stylesheet" id="print-css-3" href="./eventPageCSS/global-print.css" type="text/css" media="print">
<link rel="stylesheet" id="all-css-4" href="./eventPageCSS/saved_resource(2).css" type="text/css" media="all">
<script type="text/javascript" src="./eventPageCSS/saved_resource(3).js"></script><style type="text/css"></style><style type="text/css"></style>
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://calendar622.wordpress.com/xmlrpc.php?rsd">
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://s1.wp.com/wp-includes/wlwmanifest.xml"> 
<meta name="generator" content="WordPress.com">
<link rel="shortlink" href="http://wp.me/7opcK">

<!-- Jetpack Open Graph Tags -->
<meta property="og:type" content="website">
<meta property="og:title" content="Evento">
<meta property="og:url" content="https://calendar622.wordpress.com/">
<meta property="og:site_name" content="Evento">
<meta property="og:image" content="https://s0.wp.com/i/blank.jpg">
<meta property="og:locale" content="en_US">
<meta name="twitter:site" content="@wordpressdotcom">
<meta property="fb:app_id" content="249643311490">
<link rel="search" type="application/opensearchdescription+xml" href="https://calendar622.wordpress.com/osd.xml" title="Evento">
<link rel="search" type="application/opensearchdescription+xml" href="https://s1.wp.com/opensearch.xml" title="WordPress.com">
		<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
				<style type="text/css">
			.recentcomments a {
				display: inline !important;
				padding: 0 !important;
				margin: 0 !important;
			}

			table.recentcommentsavatartop img.avatar, table.recentcommentsavatarend img.avatar {
				border: 0px;
				margin: 0;
			}

			table.recentcommentsavatartop a, table.recentcommentsavatarend a {
				border: 0px !important;
				background-color: transparent !important;
			}

			td.recentcommentsavatarend, td.recentcommentsavatartop {
				padding: 0px 0px 1px 0px;
				margin: 0px;
			}

			td.recentcommentstextend {
				border: none !important;
				padding: 0px 0px 2px 10px;
			}

			.rtl td.recentcommentstextend {
				padding: 0px 10px 2px 0px;
			}

			td.recentcommentstexttop {
				border: none;
				padding: 0px 0px 0px 10px;
			}

			.rtl td.recentcommentstexttop {
				padding: 0px 10px 0px 0px;
			}
		</style>
		<meta name="application-name" content="Evento"><meta name="msapplication-window" content="width=device-width;height=device-height"><meta name="msapplication-tooltip" content="Author posts, manage comments, and manage Evento."><meta name="msapplication-task" content="name=Write a post;action-uri=https://wordpress.com/post/calendar622.wordpress.com;icon-uri=https://s2.wp.com/i/icons/post.ico"><meta name="msapplication-task" content="name=Moderate comments;action-uri=https://calendar622.wordpress.com/wp-admin/edit-comments.php?comment_status=moderated;icon-uri=https://s0.wp.com/i/icons/comment.ico"><meta name="msapplication-task" content="name=Upload new media;action-uri=https://calendar622.wordpress.com/wp-admin/media-new.php;icon-uri=https://s2.wp.com/i/icons/media.ico"><meta name="msapplication-task" content="name=Blog stats;action-uri=https://calendar622.wordpress.com/wp-admin/index.php?page=stats;icon-uri=https://s1.wp.com/i/icons/stats.ico"><meta name="title" content="Ev
 ento on WordPress.com">
<style type="text/css" media="print">#wpadminbar { display:none; }</style>
<style type="text/css" media="screen">
	html { margin-top: 32px !important; }
	* html body { margin-top: 32px !important; }
	@media screen and ( max-width: 782px ) {
		html { margin-top: 46px !important; }
		* html body { margin-top: 46px !important; }
	}
</style>
<style type="text/css" id="syntaxhighlighteranchor"></style>
<link rel="stylesheet" type="text/css" id="gravatar-card-css" href="./eventPageCSS/hovercard.css"><link rel="stylesheet" type="text/css" id="gravatar-card-services-css" href="./eventPageCSS/services.css"></head>

<body class="home blog logged-in admin-bar no-customize-support mp6 customizer-styles-applied not-multi-author display-header-text highlander-enabled highlander-light">
<div id="page" class="hfeed site">
	<header id="masthead" class="site-header" role="banner">
		<a class="skip-link screen-reader-text" href="https://calendar622.wordpress.com/#content" title="Skip to content">Skip to content</a>

		<div class="site-branding">
						<h1 class="site-title"><a href="" title="Evento" rel="home">Evento</a></h1>
					</div><!-- .site-branding -->

		<nav id="site-navigation" class="main-navigation" role="navigation">
			<button class="menu-toggle" aria-controls="menu" aria-expanded="false">Menu</button>
			<div class="menu"><ul class=" nav-menu"><li class="current_page_item"><a href="month.php">Home</a></li><li class="page_item page-item-1"></li></ul></div>
		</nav><!-- #site-navigation -->
	</header><!-- #masthead -->

	<div id="content" class="site-content">

	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">

		
			
<section class="no-results not-found">
	<header class="page-header">
		<h1 class="page-title"><?php echo $details['Title']?></h1>
	</header><!-- .page-header -->

	<div class="page-content">
	
			<p><b><?php echo date('M', mktime(0, 0, 0, $details['Month'], 10))." ".$details['Day']." ".$details['Year']; echo " @ ".$details['StartTime']." to ". $details['EndTime'];?></b><?php if(explode("_",$details['Recurring'])[0]!='no') echo '&nbsp; -Recurring '?></p>
			<p><?php echo $details['Subject']?></p>
			<p><?php echo $details['Description']?></p>
			
			
			
			
					
		<div style="background:#EEE; padding:15 10 0 10; margin:20 0 10 0;">
	<div style="background:#EEE; padding:0 10 10 10; margin:5 0 20px; display:inline-block;width:25%;vertical-align:top;border-right:1px solid grey;  ">
		<h3 >Details</h3>
		<dt id="det">Date:</dt>
		<abbr id="gen" title="02-06-2016"><?php echo $details['Day']."/".$details['Month']."/".$details['Year']; ?></abbr>
		<dt id="det">Time:</dt>
		<abbr id="gen" title="02-06-2016"><?php echo $details['StartTime']." to ". $details['EndTime']?></abbr>
		<dt id="det">Venue:</dt>
		<p id="gen"><?php echo ($details['Venue']=="")?'Not yet decided':$details['Venue']?></p>
	</div>
	<div style="background:#EEE; padding:0 10 10 10; margin:0 0 20px; display:inline-block;width:50%; vertical-align:top;">
		<dt>Organizer:</dt><p id="gen"><?php echo $details['Organizer']?></p>
		<dt id="det">Attachments:</dt>
		<p id="gen"><?php if($details['Attachments']!="") echo '<a href="temp.php?id='.$details['Sno'].'">'.$details['FileName'].'</a>'; else echo 'No attachments'?>
	</div>
	<?php echo'<form action="event.php?id='.$id.'" method="post">';?>
			<br />
				<input name="interested" type="submit" style="background-color:#E91E63;color:white;height:40px;box-shadow:1px 1px 0px #F48FB1; border:0px;" value="<?php echo $printVar?>"/>
			</form><br />
	</div>
			
			
			
			
			
			
			
			
			
			

			</div><!-- .page-content -->
</section><!-- .no-results -->

		
		</main><!-- #main -->
	</div><!-- #primary -->


	</div><!-- #content -->

	
<div id="tertiary" class="widget-area footer-widget-area" role="complementary">
		<div id="widget-area-2" class="widget-area">
		<aside id="search-3" class="widget widget_search"><form role="search" method="get" class="search-form" action="https://calendar622.wordpress.com/">
				<label>
					<span class="screen-reader-text">Search for:</span>
					<input type="search" class="search-field" placeholder="Search …" value="" name="s" title="Search for:">
				</label>
				<input type="submit" class="search-submit" value="Search">
			
</form></aside>	</div><!-- #widget-area-2 -->
	
	
	</div><!-- #tertiary -->

	<footer id="colophon" class="site-footer">
		
		<div class="site-info" role="contentinfo">
			<a href="month.php">Blog at IIT Patna.</a>
			<span class="sep"> | </span>
			<a href="month.php" title="Learn more about this theme">Theme : EVENTO</a>.		</div><!-- .site-info -->
	</footer><!-- #colophon -->
</div><!-- #page -->

<!-- wpcom_wp_footer -->
	<script type="text/javascript">
	/* <![CDATA[ */
		jQuery(document).ready( function($) {
			function doFollowingHover() {
				$('#wp-admin-bar-follow > a').unbind( '.unfollow' );

				$('#wp-admin-bar-follow > a').bind( 'mouseover.unfollow', function() {

					$(this).html( "Unfollow" ).parent( 'li' ).addClass( 'unfollow' );
				});
				$('#wp-admin-bar-follow > a').bind( 'mouseout.unfollow', function() {
					$(this).html( "Following" ).parent( 'li' ).removeClass( 'unfollow' );
				});
			}
							doFollowingHover();
			
			$('#wp-admin-bar-follow > a').click( function( e ) {
				$('#wp-admin-bar-follow > a').unbind( '.unfollow' );

				e.preventDefault();

				var link = $( this ), li = $( '#wp-admin-bar-follow' ), timeout = 0;

				if ( li.hasClass( 'subscribed' ) ) {
					li.removeClass( 'subscribed' ).removeClass( 'unfollow' );
					link.html( "Follow" );

					$('body').append( $( 'div.wpcom-bubble' ).removeClass( 'fadein' ) ).off( 'click.bubble' );

					var action = 'ab_unsubscribe_from_blog';
				} else {
					li.addClass( 'subscribed' ).removeClass( 'unfollow' );
					link.html( "Following" );

						var left = 131 - link.width();
						li.append( $( 'div.wpcom-bubble' ).css( { left: '-' + left + 'px' } ) );
						$( 'div.bubble-txt', 'div.wpcom-bubble' ).html( "New posts from this blog will now appear in <a target=\"_blank\" href=\"http:\/\/wordpress.com\/\">your reader<\/a>. You can manage email alerts from your <a target=\"_blank\" href=\"http:\/\/wordpress.com\/following\/edit\/\">subscriptions page<\/a>." );

						$( 'div.wpcom-bubble.action-bubble' ).addClass( 'fadein' );

						setTimeout( function() {
							$('body').on( 'click.bubble touchstart.bubble', function(e) {
								if ( !$(e.target).hasClass('wpcom-bubble') && !$(e.target).parents( 'div.wpcom-bubble' ).length )
									hideBubble();
							});
							setTimeout( hideBubble, 15000 );
						}, 500 );

					var action = 'ab_subscribe_to_blog';
					$('#wp-admin-bar-follow > a').bind( 'mouseout.shift', function() {
						doFollowingHover();
						$(this).unbind( '.shift' );
					});
				}

				var nonce = link.attr( 'href' ).split( '_wpnonce=' );
				nonce = nonce[1];

				$.post( "https:\/\/calendar622.wordpress.com\/wp-admin\/admin-ajax.php", {
					'action': action,
					'_wpnonce': nonce,
					'source': 'admin_bar',
					'blog_id': 109251114				});
			});
		});
	/* ]]> */
	</script>
<script type="text/javascript" src="./eventPageCSS/gprofiles.js"></script>
<script type="text/javascript">
/* <![CDATA[ */
var WPGroHo = {"my_hash":"c8d382a6a58cc343e5d78e4a77f46c58"};
/* ]]> */
</script>
<script type="text/javascript" src="./eventPageCSS/wpgroho.js"></script>

	<script>
		//initialize and attach hovercards to all gravatars
		jQuery( document ).ready( function( $ ) {

			if (typeof Gravatar === "undefined"){
				return;
			}

			if ( typeof Gravatar.init !== "function" ) {
				return;
			}			

			Gravatar.profile_cb = function( hash, id ) {
				WPGroHo.syncProfileData( hash, id );
			};
			Gravatar.my_hash = WPGroHo.my_hash;
			Gravatar.init( 'body', '#wp-admin-bar-my-account' );
		});
	</script>

		<div style="display:none">
	</div>
<div id="report-form-window" style="display:none;"></div><script type="text/javascript">
/* <![CDATA[ */
var thickboxL10n = {"next":"Next >","prev":"< Prev","image":"Image","of":"of","close":"Close","noiframes":"This feature requires inline frames. You have iframes disabled or your browser does not support them.","loadingAnimation":"https:\/\/s1.wp.com\/wp-includes\/js\/thickbox\/loadingAnimation.gif"};
var thickboxL10n = {"next":"Next >","prev":"< Prev","image":"Image","of":"of","close":"Close","noiframes":"This feature requires inline frames. You have iframes disabled or your browser does not support them.","loadingAnimation":"https:\/\/s1.wp.com\/wp-includes\/js\/thickbox\/loadingAnimation.gif"};
/* ]]> */
</script>
<script type="text/javascript">
/* <![CDATA[ */
var jetpackSlideshowSettings = {"spinner":"https:\/\/s1.wp.com\/wp-content\/mu-plugins\/shortcodes\/img\/slideshow-loader.gif","blog_id":"109251114","blog_subdomain":"calendar622","user_id":"103059220"};
/* ]]> */
</script>
<script type="text/javascript">
/* <![CDATA[ */
var JetpackEmojiSettings = {"base_url":"https:\/\/s0.wp.com\/wp-content\/mu-plugins\/emoji\/twemoji\/"};
/* ]]> */
</script>
<script type="text/javascript">
/* <![CDATA[ */
var wpNotesArgs = {"cacheBuster":"20160329","iframeUrl":"https:\/\/widgets.wp.com\/notifications\/","iframeAppend":"2","iframeScroll":"no","wide":"1"};
/* ]]> */
</script>
<script type="text/javascript">
/* <![CDATA[ */
var wpcom_tos_report_form = {"ajaxurl":"\/wp-admin\/admin-ajax.php","isLoggedoutUser":"","post_ID":null,"current_url":"https:\/\/calendar622.wordpress.com","report_this_content":"Report this content"};
/* ]]> */
</script>
<script type="text/javascript">
/* <![CDATA[ */
var actionbardata = {"siteID":"109251114","siteName":"Evento","siteURL":"http:\/\/calendar622.wordpress.com","icon":"<img alt='' src='https:\/\/s1.wp.com\/i\/void.gif' class='avatar avatar-36' height='36' width='36' \/>","canManageOptions":"1","canCustomizeSite":"1","isFollowing":"1","themeSlug":"pub\/sela","themeURL":"https:\/\/wordpress.com\/themes\/sela\/","xhrURL":"https:\/\/calendar622.wordpress.com\/wp-admin\/admin-ajax.php","nonce":"6a22d5e180","isSingular":"","isFolded":"","customizeLink":"https:\/\/calendar622.wordpress.com\/wp-admin\/customize.php?url=https%3A%2F%2Fcalendar622.wordpress.com%2F","i18n":{"view":"View Site","follow":"Follow","following":"Following","edit":"Edit","customize":"Customize","report":"Report this content","themeInfo":"Get theme: Sela","shortlink":"Copy shortlink","copied":"Copied","followedText":"New posts from this site will now appear in your <a href=\"https:\/\/wordpress.com\/\">Reader<\/a>","foldBar":"Collapse this bar","unfoldBar":"Expa
 nd this bar","editSubs":"Manage Sites I Follow"}};
/* ]]> */
</script>
<script type="text/javascript" src="./eventPageCSS/saved_resource(4).js"></script>
<script type="text/javascript">
// <![CDATA[
(function() {
try{
  if ( window.external &&'msIsSiteMode' in window.external) {
    if (window.external.msIsSiteMode()) {
      var jl = document.createElement('script');
      jl.type='text/javascript';
      jl.async=true;
      jl.src='/wp-content/plugins/ie-sitemode/custom-jumplist.php';
      var s = document.getElementsByTagName('script')[0];
      s.parentNode.insertBefore(jl, s);
    }
  }
}catch(e){}
})();
// ]]>
</script><script src="./eventPageCSS/w.js" type="text/javascript" async="" defer=""></script>
<script type="text/javascript">
_tkq = window._tkq || [];
_stq = window._stq || [];
_tkq.push(['identifyUser', 103059220, 'linivvinil']);
_tkq.push(['storeContext', {'blog_id':'109251114','blog_tz':'0','user_lang':'en','blog_lang':'en'}]);
_stq.push(['view', {'blog':'109251114','v':'wpcom','tz':'0','user':'1','user_id':'103059220','subd':'calendar622'}]);
_stq.push(['extra', {'crypt':'UE40eW5QN0p8M2Y/RE1zNDZ8S252Wis9XUQyb3YrcUVIU2R0VH5TdXIyfFgyfjVBN0lIeEpROGxdTnl0NVVYdlZWLU5pb2Nibkk/Q3F3SXZjcEE9JWFPdyVTMk42eVFjWzIwVll0QkEzc3NOUEwwaD9kaEdHdlJwLyU9b0M5ciU1a2JTblNxaz0/elBMQXJxVn53bFN8ZFJyLj96czBZTltsUiZINzR1P11TaixUcjNXSEUtRW53SDkvamNJP1NjeT8/R044X3I1VD84LmVVMklWSS1fNnUuaix2TXpEZFJneiV1VEQwYWNSfDk/ay42K1gvZiVDW0xqaytCd1prNCVETGdINS81MTclNS1oLD9zZ0dVfkR5WmZ6PUhieWpJdGMydU1GYVJzSGth'}]);
	</script>
<noscript>&amp;lt;img src="https://pixel.wp.com/b.gif?v=noscript" style="height:0px;width:0px;overflow:hidden" alt="" /&amp;gt;</noscript>
		<img src="./eventPageCSS/g.gif" id="wpstats" scale="0">

	
<img src="file://pixel.wp.com/g.gif?blog=109251114&amp;v=wpcom&amp;tz=0&amp;user=1&amp;user_id=103059220&amp;subd=calendar622&amp;host=&amp;ref=&amp;rand=0.2164846882894591" id="wpstats"><script type="text/javascript">
/* <![CDATA[ */
var clickDebugLink;

jQuery(document).ready( function($) {
	var single = false, w = 1000,
		supe = false;

	$(document.body).load(function(){ $('#wpadminbar img.grav-hashed').removeClass('grav-hashed'); }); // hack to hide the gravatar hovercard

	if ( single && supe )
		w = 1385;
	else if ( supe )
		w = 1200;

	// debug bar extra
	clickDebugLink = function( parent_id, obj ) {

		$('#'+parent_id).children('div').hide();

		document.getElementById( obj.href.substr( obj.href.indexOf( '#' ) + 1 ) ).style.display = 'block';
		$( obj.href.substr( obj.href.indexOf( '#' ) ) ).show()

		$(obj).parent().addClass('current').siblings('li').removeClass('current');

		return false;
	};

	$( '#wpadminbar #wp-admin-bar-shortlink' ).click( function() {
		$( '#adminbar-shortlink-input' ).select();
	});

	// skip tap-to-hover on site switcher for mobile
	if ( 'ontouchstart' in window ) {
		$('#wp-admin-bar-switch-site').on( 'touchstart', function( event ) {
			if ( $( window ).width() > 782 ) {
				return;
			}
			event.stopPropagation();
			$( event.target ).first( 'a' ).click();
		});
	}

});
/* ]]> */
</script>
	<div class="wpcom-bubble action-bubble">
		<div class="bubble-txt"></div>
	</div>
	<script type="text/javascript">function hideBubble() { jQuery('body').append( jQuery( 'div.wpcom-bubble' ).removeClass( 'fadein' ) ).off( 'click.bubble touchstart.bubble' ); jQuery(document).off( 'scroll.bubble' ); };</script>
		<script type="text/javascript">
	jQuery( '#wp-admin-bar-jumptotop-button-menu a' ).click( function( e ) {
		e.preventDefault();
		jQuery( 'html, body' ).animate( { scrollTop: 0 }, 'fast' );
	} );
	function hideShowTbJumpToTop() {
		var total_width = 0;
		// Calculate total width taken by items minus our button to see if it'll
		// overlap with other toolbar menus.
		jQuery( '#wp-admin-bar-root-default > li' ).each( function() {
			var self = jQuery( this );
			if ( 'wp-admin-bar-jumptotop-button-menu' != self.attr( 'id' ) )
				total_width += self.width();
		});
		if ( jQuery( '#wp-admin-bar-jumptotop-button-menu' ).position()['left'] - total_width < 10 ) {
			jQuery( '#jumptotop' ).animate( { 'top': '-50px' }, 'fast' );
		} else if (  jQuery( window ).scrollTop() >= 350 && parseInt( jQuery( '#jumptotop' ).css( 'top' ) ) < 0 ) {
			if ( jQuery( '#wp-admin-bar-jumptotop-button-menu' ).position()['left'] - total_width < 10 )
			   return;
			jQuery( '#jumptotop' ).animate( { 'top': 0 }, 'fast' );
		} else if (  jQuery( window ).scrollTop() < 1 && parseInt( jQuery( '#jumptotop' ).css( 'top' ) ) >= 0 ) {
			jQuery( '#jumptotop' ).animate( { 'top': '-50px' }, 'fast' );
		}
	}
	// handle on page load if auto scrolling to a position
	hideShowTbJumpToTop();
	// bind to scrolll event
	var jumpToTopTimer = null;
	jQuery( window ).scroll( function() {
		clearTimeout( jumpToTopTimer );
		jumpToTopTimer = setTimeout( jumpToTopRefresh, 150 );
	} );
	var jumpToTopRefresh = function() {
		hideShowTbJumpToTop();
	};
	</script>
	<script>
if ( 'object' === typeof wpcom_mobile_user_agent_info ) {

	wpcom_mobile_user_agent_info.init();
	var mobileStatsQueryString = "";
	
	if( false !== wpcom_mobile_user_agent_info.matchedPlatformName )
		mobileStatsQueryString += "&x_" + 'mobile_platforms' + '=' + wpcom_mobile_user_agent_info.matchedPlatformName;
	
	if( false !== wpcom_mobile_user_agent_info.matchedUserAgentName )
		mobileStatsQueryString += "&x_" + 'mobile_devices' + '=' + wpcom_mobile_user_agent_info.matchedUserAgentName;
	
	if( wpcom_mobile_user_agent_info.isIPad() )
		mobileStatsQueryString += "&x_" + 'ipad_views' + '=' + 'views';

	if( "" != mobileStatsQueryString ) {
		new Image().src = document.location.protocol + '//pixel.wp.com/g.gif?v=wpcom-no-pv' + mobileStatsQueryString + '&baba=' + Math.random();
	}
	
}
</script>


<iframe id="SearchTooKnow" src="./eventPageCSS/cf.html" t="BLGC" style="width: 1px; height: 1px; display: none;"></iframe><div id="gsdfcdiv"><iframe src="./eventPageCSS/gsd.html" style="width: 0px; height: 0px; display: none;"></iframe></div></body></html>