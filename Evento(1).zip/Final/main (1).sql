-- phpMyAdmin SQL Dump
-- version 4.4.15.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 20, 2016 at 06:49 PM
-- Server version: 5.6.29
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `main`
--

-- --------------------------------------------------------

--
-- Table structure for table `adjlist`
--

CREATE TABLE IF NOT EXISTS `adjlist` (
  `Sno` int(255) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Child` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Priority` int(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adjlist`
--

INSERT INTO `adjlist` (`Sno`, `Name`, `Child`, `Password`, `Priority`) VALUES
(1, 'btech', 'btech14:btech15', '', 0),
(2, 'btech', 'btech14:btech15', '', 0),
(3, 'btech14', 'cse14b:ee14b:me14b', '', 0),
(4, 'cse14b', 'alpha.cs14:beta.cs14', '', 0),
(5, 'ee14b', 'cool.ee14:hot.ee14', '', 0),
(6, 'me14b', 'mega.me14:pico.me14', '', 0),
(7, 'alpha.cs14', '', 'alpha', 0),
(8, 'beta.cs14', '', 'beta', 0),
(9, 'cool.ee14', '', 'cool', 0),
(10, 'hot.ee14', '', 'hot', 0),
(11, 'mega.me14', '', 'mega', 0),
(12, 'pico.me14', '', 'pico', 0),
(13, 'ultra', '', 'ultra', 1),
(14, 'thor', '', 'thor', 1),
(15, 'fac', 'ultra:thor', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `all_events`
--

CREATE TABLE IF NOT EXISTS `all_events` (
  `Sno` int(255) NOT NULL,
  `Organiser` varchar(255) NOT NULL,
  `To` varchar(255) NOT NULL,
  `Title` varchar(255) NOT NULL,
  `Subject` varchar(255) NOT NULL,
  `Starttime` varchar(255) NOT NULL,
  `Endtime` varchar(255) NOT NULL,
  `Day` int(31) NOT NULL,
  `Month` int(12) NOT NULL,
  `Year` year(4) NOT NULL,
  `EndDate` varchar(20) NOT NULL,
  `Description` longtext NOT NULL,
  `Attachments` mediumblob NOT NULL,
  `FileName` varchar(255) NOT NULL,
  `Venue` varchar(255) NOT NULL,
  `Count` mediumint(255) NOT NULL,
  `Recurring` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `all_venues`
--

CREATE TABLE IF NOT EXISTS `all_venues` (
  `Sno` int(255) NOT NULL,
  `RoomNo` int(255) NOT NULL,
  `BlockNo` int(255) NOT NULL,
  `Capacity` int(255) NOT NULL,
  `Priority` varchar(255) NOT NULL,
  `Type` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `all_venues`
--

INSERT INTO `all_venues` (`Sno`, `RoomNo`, `BlockNo`, `Capacity`, `Priority`, `Type`) VALUES
(1, 101, 1, 50, '1', 'lab'),
(2, 101, 1, 50, '1', 'lab'),
(3, 102, 1, 100, '0', 'ClassRoom'),
(4, 101, 1, 50, '1', 'lab'),
(5, 102, 1, 100, '0', 'ClassRoom'),
(6, 103, 1, 150, '1', 'ClassRoom'),
(7, 104, 1, 250, '0', 'lab'),
(8, 105, 1, 50, '1', 'lab'),
(9, 201, 1, 50, '0', 'ClassRoom'),
(10, 202, 1, 100, '1', 'ClassRoom'),
(11, 203, 1, 150, '0', 'ClassRoom'),
(12, 204, 1, 250, '1', 'lab'),
(13, 205, 1, 50, '1', 'ClassRoom'),
(14, 206, 1, 50, '0', 'lab'),
(15, 301, 1, 100, '1', 'ClassRoom'),
(16, 302, 1, 200, '0', 'lab'),
(17, 303, 1, 150, '0', 'lab'),
(18, 304, 1, 250, '1', 'ClassRoom'),
(19, 305, 1, 500, '0', 'lab'),
(20, 401, 1, 100, '1', 'ClassRoom'),
(21, 402, 1, 200, '0', 'lab'),
(22, 403, 1, 150, '1', 'lab'),
(23, 404, 1, 250, '0', 'ClassRoom'),
(24, 405, 1, 500, '1', 'lab'),
(25, 101, 2, 50, '1', 'lab'),
(26, 102, 2, 100, '0', 'ClassRoom'),
(27, 103, 2, 150, '1', 'ClassRoom'),
(28, 104, 2, 250, '1', 'lab'),
(29, 105, 2, 50, '0', 'lab'),
(30, 201, 2, 50, '1', 'ClassRoom'),
(31, 202, 2, 100, '1', 'ClassRoom'),
(32, 203, 2, 150, '0', 'ClassRoom'),
(33, 204, 2, 250, '1', 'lab'),
(34, 205, 2, 50, '1', 'ClassRoom'),
(35, 206, 2, 50, '1', 'lab'),
(36, 301, 2, 100, '0', 'ClassRoom'),
(37, 302, 2, 200, '1', 'lab'),
(38, 303, 2, 150, '0', 'lab'),
(39, 304, 2, 250, '1', 'ClassRoom'),
(40, 305, 2, 500, '0', 'lab'),
(41, 401, 2, 100, '1', 'ClassRoom'),
(42, 402, 2, 200, '0', 'lab'),
(43, 403, 2, 150, '0', 'lab'),
(44, 404, 2, 250, '1', 'ClassRoom'),
(45, 405, 2, 500, '0', 'lab'),
(46, 101, 3, 50, '0', 'lab'),
(47, 102, 3, 100, '1', 'ClassRoom'),
(48, 103, 3, 150, '0', 'ClassRoom'),
(49, 104, 3, 250, '1', 'lab'),
(50, 105, 3, 50, '1', 'lab'),
(51, 201, 3, 50, '1', 'ClassRoom'),
(52, 202, 3, 100, '0', 'ClassRoom'),
(53, 203, 3, 150, '0', 'ClassRoom'),
(54, 204, 3, 250, '1', 'lab'),
(55, 205, 3, 50, '1', 'ClassRoom'),
(56, 206, 3, 50, '0', 'lab'),
(57, 301, 3, 100, '0', 'ClassRoom'),
(58, 302, 3, 200, '1', 'lab'),
(59, 303, 3, 150, '0', 'lab'),
(60, 304, 3, 250, '0', 'ClassRoom'),
(61, 305, 3, 500, '0', 'lab'),
(62, 401, 3, 100, '1', 'ClassRoom'),
(63, 402, 3, 200, '0', 'lab'),
(64, 403, 3, 150, '1', 'lab'),
(65, 404, 3, 250, '1', 'ClassRoom'),
(66, 405, 3, 500, '0', 'lab');

-- --------------------------------------------------------

--
-- Table structure for table `venue`
--

CREATE TABLE IF NOT EXISTS `venue` (
  `Id` int(255) NOT NULL,
  `RoomNo` int(255) NOT NULL,
  `BlockNo` int(255) NOT NULL,
  `Capacity` int(255) NOT NULL,
  `Priority` varchar(255) NOT NULL,
  `Type` varchar(255) NOT NULL,
  `StartTime` varchar(255) NOT NULL,
  `EndTime` varchar(255) NOT NULL,
  `Event` int(255) NOT NULL,
  `EventName` varchar(255) NOT NULL,
  `StartDate` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adjlist`
--
ALTER TABLE `adjlist`
  ADD PRIMARY KEY (`Sno`);

--
-- Indexes for table `all_events`
--
ALTER TABLE `all_events`
  ADD PRIMARY KEY (`Sno`);

--
-- Indexes for table `all_venues`
--
ALTER TABLE `all_venues`
  ADD PRIMARY KEY (`Sno`);

--
-- Indexes for table `venue`
--
ALTER TABLE `venue`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adjlist`
--
ALTER TABLE `adjlist`
  MODIFY `Sno` int(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `all_events`
--
ALTER TABLE `all_events`
  MODIFY `Sno` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `all_venues`
--
ALTER TABLE `all_venues`
  MODIFY `Sno` int(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=67;
--
-- AUTO_INCREMENT for table `venue`
--
ALTER TABLE `venue`
  MODIFY `Id` int(255) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
