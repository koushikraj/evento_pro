<?php
error_reporting(0);

if(isset($_GET['id'])){
$id = $_GET['id'];
mysql_connect("localhost","bora.cs14","bora@678") or die("Cannot connect to databse");
mysql_select_db('main') or die("cannot select db");
$query = "SELECT FileName,Attachments " .
         "FROM all_events WHERE Sno = '$id'";

$result = mysql_query($query) or die('Error, query failed'.mysql_error());
$row = mysql_fetch_assoc($result);

header("Content-Disposition: attachment; filename=".$row['FileName']);
echo $row['Attachments'];
 
exit;
}

?>