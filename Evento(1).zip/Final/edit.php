<?php
session_start();
error_reporting(0);
if(isset($_POST['id'])){
	mysql_connect("localhost","bora.cs14","bora@678") or die("Cannot connect to databse");
	$id = $_POST['id'];
	$_SESSION['Id'] = $id;
	/*************validate**************/
	mysql_select_db($_SESSION['User']) or die("cannot select db");
	$query = "SELECT * FROM my_events WHERE Pointer='$id'";
	$result =  mysql_query($query) or die('cannot get results! '.mysql_error());
	if(mysql_num_rows($result)==0)
		die('Something\'s Wrong Try again later');
	
	/*************************************/
	
	/*************get details**************/
	mysql_select_db('main') or die("cannot select db");
	
	$query = "SELECT * FROM all_events WHERE Sno='$id'";
	$result =  mysql_query($query) or die('cannot get results! '.mysql_error());
	$details = mysql_fetch_assoc($result);	
	
}

if(isset($_POST['to'])&&isset($_POST['eventName'])&&isset($_POST['subject'])&&isset($_POST['stime'])&&isset($_POST['etime'])&&isset($_POST['date'])&&isset($_POST['desc'])&&isset($_SESSION['Id'])){
$id = $_SESSION['Id'];
$to = $_POST['to'];
$cc = $_POST['cc'];
$title = $_POST['eventName'];
$subject = $_POST['subject'];
$stime = $_POST['stime'];
$etime = $_POST['etime'];
$date = $_POST['date'];
$day = explode("-",$date)[2];
$year = explode("-",$date)[0];
$mon = explode("-",$date)[1];
$desc = mysql_real_escape_string(nl2br($_POST['desc']));

if($_POST['check']==0)
	$recur = 'no';
else{
	
	if(isset($_POST['mode'])&&isset($_POST['n'])&&isset($_POST['m'])&&isset($_POST['edate'])){
			$_SESSION['mode']=$_POST['mode'];
			$_SESSION['n']=$_POST['n'];
			$_SESSION['m']=$_POST['m'];
			$_SESSION['edate']=$_POST['edate'];
			
			if($_POST['mode']=="0"){
				$n = $_POST['n'];
				$recur="Day_".$n;
				
			}
			else if($_POST['mode']=="1"){
				$n = $_POST['n'];
				$recur="Week_".$n;
				
			}
			else if($_POST['mode']=="2"){
				$n = $_POST['n'];
				$recur="Month_".$n;
				
			}
			else if($_POST['mode']=="3"){
				$n = $_POST['n'];
				$m = $_POST['m'];
				$recur="Year_".$n."_".$m;
				
			}
		$edate=$_POST['edate'];
	}
}
	
if($_FILES['userfile']['size'] > 0)
{
$fileName = $_FILES['userfile']['name'];
$tmpName  = $_FILES['userfile']['tmp_name'];
$fileSize = $_FILES['userfile']['size'];
$fileType = $_FILES['userfile']['type'];

$fp      = fopen($tmpName, 'r');
$content = fread($fp, filesize($tmpName));
$content = addslashes($content);
fclose($fp);

if(!get_magic_quotes_gpc())
{
    $fileName = addslashes($fileName);
}
}
mysql_connect("localhost","bora.cs14","bora@678") or die("Cannot connect to databse");
mysql_select_db('main') or die("cannot select db");

$query = "UPDATE all_events SET `To`='$to' ,Title='$title' ,Subject='$subject' ,StartTime='$stime' ,EndTime='$etime' ,Day='$day' ,Month='$mon' ,Year='$year' ,Description='$desc' ,Attachments='$content' ,FileName='$fileName' ,Recurring='$recur' ,EndDate='$edate' WHERE Sno='$id'";
$result = mysql_query($query) or die('cannot get results! '.mysql_error());


if($_POST['venue']==1){
	$query="DELETE FROM venue WHERE Event='$id'";
	$result = mysql_query($query) or die('cannot get results! '.mysql_error());
	header("Location: venue.php");
}
else if($_POST['venue']==0){
	$_SESSION['Id']=NULL;
	header("Location: myevents.php");
}
	

}
?>


<!DOCTYPE html>
<html class=" js rgba multiplebgs backgroundsize borderradius boxshadow textshadow opacity cssgradients csstransitions generatedcontent js rgba multiplebgs backgroundsize borderradius boxshadow textshadow opacity cssgradients csstransitions generatedcontent" lang="en"><!--<![endif]--><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Evento</title>

<meta name="robots" content="noindex,follow">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<link  href="./docs/css/datepicker.css" rel="stylesheet">
<script src="./docs/js/datepicker.js"></script>
<link  href="notify.css" rel="stylesheet">
<link rel="icon" href="favicon.ico" type="image/x-icon" />


	<script type="text/javascript">
		/* <![CDATA[ */
		function addLoadEvent(func) {
			var oldonload = window.onload;
			if (typeof window.onload != 'function') {
				window.onload = func;
			} else {
				window.onload = function () {
					oldonload();
					func();
				}
			}
		}
		/* ]]> */
	</script>
	<script>
$(document).ready(function(){
    jQuery("#A").click(function(){
        if(jQuery('.floorA').is(":visible"))
        jQuery('.floorA').hide();
        else
        jQuery(".floorA").show();
    });
	jQuery("#B").click(function(){
        if(jQuery('.floorB').is(":visible"))
        jQuery('.floorB').hide();
        else
        jQuery(".floorB").show();
    });
	jQuery("#C").click(function(){
        if(jQuery('.floorC').is(":visible"))
        jQuery('.floorC').hide();
        else
        jQuery('.floorC').show();
    });
	$('[data-toggle="datepicker"]').datepicker({
		format: 'yyyy-mm-dd'
	});
	$('#textdat').attr("readonly",true);
});
</script>

	<link rel="stylesheet" id="all-css-0" href="./eventoCSS/saved_resource_compose.css" type="text/css" media="all">


<link rel="stylesheet" id="all-css-6" href="./eventoCSS/saved_resource(1).css" type="text/css" media="all">
			<link rel="stylesheet" type="text/css" href="bookstyle.css">

<link href="https://fonts.googleapis.com/css?family=Cutive" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet" type="text/css">
<link rel="stylesheet" id="all-css-8" href="./eventoCSS/saved_resource(2).css" type="text/css" media="all">
<script type="text/javascript">
/* <![CDATA[ */
var LoggedOutFollow = {"invalid_email":"Your subscription did not succeed, please try again with a valid email address."};
/* ]]> */
</script>
<script type="text/javascript" src="./eventoCSS/saved_resource(3).js"></script>

<!--[if lt IE 8]>
<link rel='stylesheet' id='highlander-comments-ie7-css'  href='https://s1.wp.com/wp-content/mu-plugins/highlander-comments/style-ie7.css?m=1351637563h&#038;ver=20110606' type='text/css' media='all' />
<![endif]-->

 
<meta name="generator" content="WordPress.com">



<!-- Jetpack Open Graph Tags -->
<meta property="og:type" content="article">
<meta property="og:title" content="Calendar">
<meta property="og:url" content="https://eventbritevenuedemo.wordpress.com/calendar/">
<meta property="og:description" content="Visit the post for more.">
<meta property="article:published_time" content="2013-09-10T19:46:38+00:00">
<meta property="article:modified_time" content="2013-09-10T19:46:38+00:00">
<meta property="og:site_name" content="Eventbrite Multi">
<meta property="og:image" content="https://s0.wp.com/i/blank.jpg">
<meta property="og:locale" content="en_US">
<meta name="twitter:site" content="@wordpressdotcom">
<meta name="twitter:card" content="summary">
<meta name="twitter:description" content="Visit the post for more.">
<meta property="fb:app_id" content="249643311490">
<meta property="article:publisher" content="https://www.facebook.com/WordPresscom">


<link rel="stylesheet" type="text/css" href="">




		<style type="text/css">
			.recentcomments a {
				display: inline !important;
				padding: 0 !important;
				margin: 0 !important;
			}

			table.recentcommentsavatartop img.avatar, table.recentcommentsavatarend img.avatar {
				border: 0px;
				margin: 0;
			}

			table.recentcommentsavatartop a, table.recentcommentsavatarend a {
				border: 0px !important;
				background-color: transparent !important;
			}

			td.recentcommentsavatarend, td.recentcommentsavatartop {
				padding: 0px 0px 1px 0px;
				margin: 0px;
			}

			td.recentcommentstextend {
				border: none !important;
				padding: 0px 0px 2px 10px;
			}

			.rtl td.recentcommentstextend {
				padding: 0px 10px 2px 0px;
			}

			td.recentcommentstexttop {
				border: none;
				padding: 0px 0px 0px 10px;
			}

			.rtl td.recentcommentstexttop {
				padding: 0px 10px 0px 0px; 
			}
		</style>
		<meta name="application-name" content="Eventbrite Multi"><meta name="msapplication-window" content="width=device-width;height=device-height"><meta name="msapplication-tooltip" content="Connect to Eventbrite with your WordPress.com theme"><meta name="msapplication-task" content="name=Subscribe;action-uri=https://eventbritevenuedemo.wordpress.com/feed/;icon-uri=https://s2.wp.com/i/favicon.ico"><meta name="msapplication-task" content="name=Sign up for a free blog;action-uri=http://wordpress.com/signup/;icon-uri=https://s2.wp.com/i/favicon.ico"><meta name="msapplication-task" content="name=WordPress.com Support;action-uri=http://support.wordpress.com/;icon-uri=https://s2.wp.com/i/favicon.ico"><meta name="msapplication-task" content="name=WordPress.com Forums;action-uri=http://forums.wordpress.com/;icon-uri=https://s2.wp.com/i/favicon.ico"><meta name="title" content="Calendar | Eventbrite Multi on WordPress.com">
<meta name="description" content="Connect to Eventbrite with your WordPress.com theme">
		<style type="text/css">
					header .logo-text h1,
			header .logo-text h5 {
				color: #fff;
			}
			#tab{
				width:100%;
			}
			#value{
				width:5%;
				padding-right:0px;
				padding-top:20px;
				text-align:left;
				
			}
			#put{
				width:85%;
				padding-left:0px;
				border-bottom:0px solid black;
			}
			tr{
				padding-left:0px;
			}
			td{
				margin:0px;
				padding:0px;
				
			}
			input::-webkit-input-placeholder {
			}

				</style>
				<style type="text/css" id="eventbrite-header-css">
		header[role=banner] {
			background: url(https://eventbritevenuedemo.files.wordpress.com/2014/10/cropped-cropped-ola-bread-tray-1.jpg) top center no-repeat;
			background-size: cover;
		}
		</style>
		<style type="text/css" id="custom-background-css">
body.custom-background { background-image: url('https://s0.wp.com/wp-content/themes/pub/eventbrite-venue/img/bg-main.png'); background-repeat: repeat; background-position: top left; background-attachment: scroll; }
</style>
<style type="text/css" id="syntaxhighlighteranchor"></style>
			<style id="demo-site-activation">
				#infinite-footer {
					display: none !important;
				}

				@media screen and (max-width: 600px) {
					.demosite-activate {
						position: absolute;
					}
				}
			</style>
					<style id="demo-site-activation-logged-out">
				
				@media screen and (max-width: 620px) {
					html {
						margin-top: 100px !important;
					}
				}
				@media screen and (max-width: 600px) {
					.demosite-activate {
						position: absolute;
					}
				}
			</style>
		</head>

<body class="page page-id-108 page-template-default custom-background mp6 customizer-styles-applied template-calendar highlander-enabled highlander-light demo-site" data-pinterest-extension-installed="cr1.39.1">
		<header role="banner">
		<div class="container">
			<div class="logo-row">
												<a class="logo-text">
					<h1 style="font-family:Cutive;">Evento</h1>
					<h5 style="font-family:Raleway;">Connect to Evento with your Webmail facilities</h5>
					<br>
				</a>
			</div>
		</div>
	</header>
	<br>

	<section role="main" class="main-container">
		<div id="site-container" class="container">
			<nav class="menu">
			<ul id="menu-main-menu" class="menu">
	<li id="menu-item-112" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-108 current_page_item menu-item-112"><a>All Events</a>
		<ul class="sub-menu">
		<li id="menu-item-122" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-122"><a href="month.php">Month View</a></li>
		<li id="menu-item-117" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-117"><a href="week.php">Week View</a></li>
		<li id="menu-item-116" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-116"><a href="day.php">Day View</a></li>
		</ul>
	</li>
	<li id="menu-item-151" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-151"><a>My Schedule</a>
		<ul class="sub-menu">
		<li id="menu-item-122" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-122"><a href="mymonth.php">Month View</a></li>
		<li id="menu-item-117" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-117"><a href="myweek.php">Week View</a></li>
		<li id="menu-item-116" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-116"><a href="myday.php">Day View</a></li>
		</ul>
	</li>
	<li id="menu-item-111" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-111"><a href="myevents.php">My Events</a></li>
	<li id="menu-item-114" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-114"><a href="#">Venues</a>

	</li>
	<li id="menu-item-113" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-113"><a href="compose.php">Compose</a></li>
	<li id="menu-item-113" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-113" style="float:right;"><a href="logout.php"><img src="logout.png"></a></li>
	<li id="menu-item-113" class="dropdown" style="float:right;"><a onclick="myFunction()" class="dropbtn"><span onclick="myFunction()"><img src="notification.png"></a></li>
	<li id="menu-item-113" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-113" style="float:right; border-right: 1px solid #666;"><a href="search.php"><img src="Search.png"></span></a></li>
	</ul>
	</nav>
	
	<div id="myDropdown" class="dropdown-content">
    <br />
	<p style="text-align:center;">NOTIFICATIONS</p>
	<hr style="margin:6px;border-top: 1px solid black;"/>
	<?php
		error_reporting(0);
		session_start();
		
		mysql_connect("localhost","bora.cs14","bora@678") or die("Cannot connect to databse");
		mysql_select_db($_SESSION['User']) or die("Cannot find database");
		$query = "SELECT * FROM notifications ORDER BY Sno DESC";
		$result = mysql_query($query) or die('cannot get results!');
		$notify = array();

		while($row = mysql_fetch_assoc($result)) {
			$notify[] = $row['Data'];
		}
		$flag=1;
	foreach($notify as $data){
		if($flag){
				echo '<b id="grey">'.$data.'</b>';
				$flag=!$flag;
		}
		else{
			  echo '<b id="white" >'.$data.'</b>';
			  $flag=!$flag;
		}
		
	}
		
	?>
	</div>
	<script>
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {

    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>


<div class="row">
	<div class="span12">

<fieldset id="fieldset" style="font:courier">

	<form action="edit.php" id="editter" method= "post"  style="font-family:comic sans ms" enctype="multipart/form-data">
		<div >
			<table id="tab"><tr id="inputs">
				<td id="value">To:</td>
				<td id="put"><input id="text" name="to" type="text" value="<?php if(isset($_POST['id'])) echo $details['To'] ?>"></td>
			</tr>
			<tr id="inputs">
				<td id="value">Title:</td>
				<td id="put"><input id="text" name="eventName" type="text" value="<?php if(isset($_POST['id'])) echo $details['Title'] ?>"></td>
			</tr>
			<tr id="inputs">
				<td id="value">Subject:</td>
				<td id="put"><input id="text" name="subject" type="text" value="<?php if(isset($_POST['id'])) echo $details['Subject'] ?>"></td>
			</tr>
			<tr id="inputs">
				<td id="value">Organizer:</td>
				<td id="put"><input id="text" name="org" type="text" value="<?php if(isset($_POST['id'])) echo $details['Organizer'] ?>"></td>
			</tr>
			</table>
<br/><br/>		
		<table id="tab">
		
			<tr>
			<td >Start:</td><td> <input name="stime" type="time" value="<?php if(isset($_POST['id'])) echo $details['StartTime']; ?>"></td><td>Date:&nbsp; <input style="height:20px" type="text" id="textdat" name="date" data-toggle="datepicker" autocomplete="off" placeholder="yyyy-mm-dd" value="<?php if(isset($_POST['id'])) echo ''.$details['Year'].'-'.sprintf("%02d",$details['Month']).'-'.sprintf("%02d",$details['Day']) ?>">
</td><td>Priority&nbsp;
			<select name="mailprio">
				<option value="1">High</option>
				<option value="3" selected="selected">Normal</option>
				<option value="5">Low</option>
			</select></td>
			</tr>
			<tr>
			<td > End:</td><td><input name="etime" type="time" value="<?php if(isset($_POST['id'])) echo $details['EndTime']?>" ></td><td>Recurring: <input name="check" type="hidden" value="0"> <input name="check" type="checkbox"  value="1" onchange="fire()" <?php if(isset($_POST['id']) && explode("_",$details['Recurring'])[0]!='no') echo 'checked' ?>/></td><td></td>
			</tr>
		
		</table>
		</div>
				
		 <br />
		
		<span style="<?php if(isset($_POST['id']) && explode("_",$details['Recurring'])[0]!='no') echo 'display:inline;'; else echo 'display:none;' ?>" id="hider">
			<select name="mode" >
				<option id="daily" value="0" onclick="" <?php if(isset($_POST['id']) && explode("_",$details['Recurring'])[0]=='Day') echo 'selected="selected"'?> >daily</option>
				<option id="weekly"  value="1" <?php if(isset($_POST['id']) && explode("_",$details['Recurring'])[0]=='Week') echo 'selected="selected"'?>>weekly</option>
				<option id="monthly" value="2" <?php if(isset($_POST['id']) && explode("_",$details['Recurring'])[0]=='Month') echo 'selected="selected"'?>>monthly</option>
				<option id="yearly" value="3" <?php if(isset($_POST['id']) && explode("_",$details['Recurring'])[0]=='Year') echo 'selected="selected"'?>>yearly</option>
			</select>
			&nbsp; &nbsp; <input name="n" style="width:60px" type="number" min="0" value="<?php if(isset($_POST['id']) && explode("_",$details['Recurring'])[0]!='no') echo explode("_",$details['Recurring'])[1]?>" > &nbsp; &nbsp; <input name="m" style="width:60px"type="number" min="1" max="12" value="<?php if(isset($_POST['id']) && explode("_",$details['Recurring'])[0]!='no') echo explode("_",$details['Recurring'])[2]?>" >
			&nbsp; &nbsp;End Date: <input style="height:20px" type="text" id="textdat" name="edate" data-toggle="datepicker" autocomplete="off" placeholder="yyyy-mm-dd" value="<?php if(isset($_POST['id']) && explode("_",$details['Recurring'])[0]!='no') echo $details['EndDate'] ?>">
		</span>

<br />
<br />

		<div style="float :left" >&nbsp; &nbsp;Description:</div>
		<textarea name="desc" id="description" rows="10" cols="125"><?php echo $details['Description']?></textarea>

	<br /><br />

		<div id="attach">Attach:
			<input name="userfile" size="48" type="file" />
(max.&nbsp;30<small>&nbsp;M</small>)<input name="MAX_FILE_SIZE" value="30971520" type="hidden"></div><br />
<input type="hidden" name="shake" value="1">
<input name="venue" type="hidden">
<input id="book animated shake" type="button" onclick="bye()" value="Go">

	</form>

</fieldset>

<script>


flag=<?php if($details['Recurring']=='no') echo 1; else echo 0?>;

function fire(){
	
	if(flag){
		document.getElementById("hider").style.display = "inline";
	
		flag=0;
	}
	else{
			document.getElementById("hider").style.display = "none";
	
		flag=1;
	}

}


function bye(){
	
	if(document.getElementsByName("stime")[0].value != "<?php echo $details['StartTime']; ?>" || document.getElementsByName("etime")[0].value !="<?php echo $details['EndTime']; ?>" || document.getElementsByName("date")[0].value !="<?php echo $details['Year']."-".sprintf("%02d",$details['Month'])."-".sprintf("%02d",$details['Day']); ?>" || document.getElementsByName("edate")[0].value !="<?php echo $details['EndDate']; ?>"  || document.getElementsByName("n")[0].value != "<?php if(isset($_POST['id']) && explode("_",$details['Recurring'])[0]!='no') echo explode("_",$details['Recurring'])[1]?>" || document.getElementsByName("m")[0].value != "<?php if(isset($_POST['id']) && explode("_",$details['Recurring'])[0]!='no') echo explode("_",$details['Recurring'])[2]?>" ){
		var x = confirm('Changing time or date will redirect you to venue page cancelling your previous venue booking.\nDo you want to continue?');
		
		if(x){
			document.getElementsByName("venue")[0].value=1;
			document.forms['editter'].action="venue.php";
			document.forms['editter'].submit();
		}
	}
	else{

		document.getElementsByName("venue")[0].value=0;
		document.forms['editter'].submit();
	}
	
}



</script>

</div>
</div>
	</div>
</section>
<footer class="site-footer row" role="contentinfo">
	<div class="container">
		<div class="pull-right"><ul id="menu-footer-menu" class="menu"><li id="menu-item-123" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-123"><a href="#">All Events</a></li>
<li id="menu-item-124" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-108 current_page_item menu-item-124"><a href="about.html">about</a></li>
</ul></div>		<p>
			<a href="#">Blog at IIT Patna</a>
			Theme: Evento Venue by <a rel="designer" class="designer-link" href="#">Platform @Btech14</a>.		</p>
		<p>
			<a class="wordpress-link" href="#">Webmail teamed up with Evento</a>
		</p>
	</div>
</footer>
</body></html>
