<?php
session_start();
error_reporting(0);

$Err = "";

if($_SESSION['flag']=="logout"){
	$_SESSION['flag']= NULL;
	echo "<script>alert('Succesfully logged out')</script>";

}

if(isset($_POST["username"]) && isset($_POST["password"])){
	mysql_connect("localhost","bora.cs14","bora@678") or die("Cannot connect to databse");
	mysql_select_db('main') or die("Cannot find database");
	$username = trim($_POST["username"]);
	$password = trim($_POST["password"]);

	$query1 = "SELECT * FROM adjlist WHERE Name='$username' AND Password='$password'";
	$result1 = mysql_query($query1);
	
	if (!$result1) 
		die('Invalid query:' . mysql_error());
	if(mysql_num_rows($result1) == 1){
		echo "Logged in succesfully";
		$_SESSION['User'] = $username;
		header("Location: month.php");
	}
	else{
		$Err = "ERR_BAD_CREDENTIALS";
	}
}


?>




<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>Login Page</title>
    
        <link rel="stylesheet" href="css/lstyle.css">
		  <link rel="stylesheet" href="animate.css">

    
  </head>

  <body>

    <html>

<head>
  <meta charset="UTF-8">
  <title>Login Page</title>


  <link rel="stylesheet" href="css/lstyle.css">


</head>

<body>

  <html lang="en">

  <head>
    <title>Login Page</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
    <link href='http://fonts.googleapis.com/css?family=Raleway:400,100' rel='stylesheet' type='text/css'>
  </head>
<link rel="icon" href="favicon.ico" type="image/x-icon" />

  <body>
    <div id="container">
      <div id="logo_bar">
        <img id="logo" src="icon.ico" style="font-weight:400;width:100px;margin-bottom:20px" alt="logo"> <span style="font-weight:400;font-size:50px;">Evento</span>
      </div>
      <div id="form_box">
        <form action="index.php" method="post">
          <p id="form_heading">Login Form</p>
          <input type="username" name="username" placeholder="Enter Username"><br />
          <input type="password" name="password" placeholder="Enter Password"><br />
          <input type="checkbox" id="checkbox"><label for="checkbox" style="color:white; font-size:15px;">Remember Me</label><br />
          <input <?php if(isset($_POST['username']) && isset($_POST['password'])) echo "id='book animated shake' " ?>type="submit" value="Login"><br />
<br />
        </form>
      </div>
    </div>
  </body>

  </html>


</body>

</html>
    
    
    
    
    
  </body>
</html>

