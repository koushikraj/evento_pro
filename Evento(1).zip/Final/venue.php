<?php
error_reporting(0);
session_start();
//$_SESSION['User']="bora.cs14";
if($_SESSION['User']!=null){



/************************************Create Event****************************************************************/
if(isset($_POST['to'])&&isset($_POST['eventName'])&&isset($_POST['subject'])&&isset($_POST['stime'])&&isset($_POST['etime'])&&isset($_POST['date'])&&isset($_POST['desc'])){
$to = $_POST['to'];
$cc = $_POST['cc'];
$title = $_POST['eventName'];
$subject = $_POST['subject'];
$stime = $_POST['stime'];
$etime = $_POST['etime'];
$date = $_POST['date'];
$day = explode("-",$date)[2];
$year = explode("-",$date)[0];
$mon = explode("-",$date)[1];
$desc = mysql_real_escape_string(nl2br($_POST['desc']));
$org = $_POST['org'];

if($_POST['check']==0)
	$recur = 'no';
else{
	
	if(isset($_POST['mode'])&&isset($_POST['n'])&&isset($_POST['m'])&&isset($_POST['edate'])){
			$_SESSION['mode']=$_POST['mode'];
			$_SESSION['n']=$_POST['n'];
			$_SESSION['m']=$_POST['m'];
			$_SESSION['edate']=$_POST['edate'];
			
			if($_POST['mode']=="0"){
				$n = $_POST['n'];
				$recur="Day_".$n;
				
			}
			else if($_POST['mode']=="1"){
				$n = $_POST['n'];
				$recur="Week_".$n;
				
			}
			else if($_POST['mode']=="2"){
				$n = $_POST['n'];
				$recur="Month_".$n;
				
			}
			else if($_POST['mode']=="3"){
				$n = $_POST['n'];
				$m = $_POST['m'];
				$recur="Year_".$n."_".$m;
				
			}
		$edate=$_POST['edate'];
	}
}
	
if($_FILES['userfile']['size'] > 0)
{
$fileName = $_FILES['userfile']['name'];
$tmpName  = $_FILES['userfile']['tmp_name'];
$fileSize = $_FILES['userfile']['size'];
$fileType = $_FILES['userfile']['type'];

$fp      = fopen($tmpName, 'r');
$content = fread($fp, filesize($tmpName));
$content = addslashes($content);
fclose($fp);

if(!get_magic_quotes_gpc())
{
    $fileName = addslashes($fileName);
}
}
mysql_connect("localhost","bora.cs14","bora@678") or die("Cannot connect to databse");
mysql_select_db('main') or die("cannot select db");

$query = "INSERT INTO all_events(Sno,Organizer,`To`,Title,Subject,StartTime,EndTime,Day,Month,Year,Description,Attachments,FileName,Recurring,EndDate,Venue,Count) VALUES(NULL,'$org','$to','$title','$subject','$stime','$etime','$day','$mon','$year','$desc','$content','$fileName','$recur','$edate','','0')";
$result = mysql_query($query) or die('cannot get results! '.mysql_error());

$query = "SELECT Sno FROM all_events WHERE Title='$title' AND Subject='$subject' AND StartTime='$stime' AND Day='$day' AND Month='$mon' AND Year='$year' AND Description='$desc'";
$result =  mysql_query($query) or die('cannot get results! '.mysql_error());
$id = mysql_fetch_array($result)[0];
$name=	mysql_fetch_assoc($result)['Title'];
$_SESSION['EventId'] = $id;
$_SESSION['EventName']= $name;

/*********add to my events******************/
mysql_select_db($_SESSION['User']) or die("cannot select db");
$query = "INSERT INTO my_events (Sno,Pointer) VALUES(NULL,'$id')";
$result = mysql_query($query) or die('cannot get results! '.mysql_error());
/*****************************Get Adj List*****************************************/

mysql_select_db("main") or die("Cannot find database ");

$query = "SELECT * FROM adjlist";
$adjlist = array();
$result = mysql_query($query) or die('cannot get results! '.mysql_error());
while($row = mysql_fetch_assoc($result)) {
	
	$adjlist[$row['Name']] = explode(":",$row['Child']);
}
echo "<br /><br />";
echo "<br /><br />";

/****************************decode to**************/

function recursion($to,&$ret,$adjlist){
	
	if($adjlist[$to][0]!=""){
		foreach ($adjlist[$to] as $temp)
			recursion($temp,$ret,$adjlist);		
	}
		
	else{	
		array_push($ret,$to);
		}
}

/***************************************************/

/*******************************************************************************/

$ret = array();
recursion($to,$ret,$adjlist);
$tos = $ret;

/*******************************************************************************/

foreach ($tos as $name){
	
	if(mysql_select_db($name)){
		$query = "INSERT INTO all_events(Sno,Pointer,Intersted) VALUES(NULL,'$id',0)";
		$result = mysql_query($query) or die('cannot get results! '.mysql_error());
			
		//	header("Location: month.php");
	}
}

}
/*******************************************************************************/
//End Create event




















/************************************

	Filter
	
*************************************/

if(isset($_POST['capacity'])&& isset($_POST['vtype']) && isset($_POST['stime']) && isset($_POST['etime']) && isset($_POST['date']) &&!empty($_POST['capacity']) &&!empty($_POST['vtype'])&&!empty($_POST['stime'])&&!empty($_POST['etime'])&&!empty($_POST['date'])){
$capacity=$_POST['capacity'];
$stime=$_POST['stime'].':00';
$etime=$_POST['etime'].':00';
$date=$_POST['date'];
$vtype = $_POST['vtype'];
$_SESSION['stime'] = $stime;
$_SESSION['etime'] = $etime;
$_SESSION['sdate'] = $date;


/* Get priority from adjlist */
mysql_connect("localhost","bora.cs14","bora@678") or die("Cannot connect to databse");
mysql_select_db("main") or die("Cannot find database");

$query = "SELECT Priority FROM adjlist WHERE Name='".$_SESSION['User']."'";
$result=mysql_query($query) or die('cannot get results!'.mysql_error());
$row = mysql_fetch_assoc($result);
$priority = $row['Priority'];

/*  Current user quota  */




	$rooms = array();
if(isset($_SESSION['mode'])&&isset($_SESSION['n'])&&isset($_SESSION['edate'])&&$_SESSION['mode']!=NULL&&$_SESSION['n']!=NULL&& $_SESSION['edate']!=NULL){
/*********************Recurring*************************/
$mode=$_SESSION['mode'];
$n=$_SESSION['n'];
$m=$_SESSION['m'];
$edate=$_SESSION['edate'];
if($mode=="0"){
		
		$curr = $date;
		
		$n=" + ".$n." days" ;
		$edate = date('Y-m-d', strtotime($edate.$n));
		
		while(strtotime($curr)<strtotime($edate)){
			
			$query = "SELECT * FROM venue WHERE StartDate='$curr' AND ((CAST(StartTime as time) <= '$stime' AND CAST(EndTime as time) >= '$stime') OR (CAST(StartTime as time) <= '$etime' AND CAST(StartTime as time) >= '$stime') OR (CAST(StartTime as time) <= '$etime' AND CAST(EndTime as time) >= '$etime')) AND Type='$vtype'";
			$result=mysql_query($query) or die('cannot get results!'.mysql_error());
			while($row = mysql_fetch_assoc($result)){
				
				if(!(isset($rooms[$row['RoomNo']]) && $rooms[$row['RoomNo']]['Priority']==$priority))
					$rooms[$row['RoomNo']] = $row;
			}
			$curr = date('Y-m-d', strtotime($curr.$n));
			
		}
		
	}
	elseif($mode=='1'){
		
		$n = " + 7 days";
		$curr = $date;
		$edate = date('Y-m-d', strtotime($edate.$n));

		while(strtotime($curr)<strtotime($edate)){
			$query = "SELECT * FROM venue WHERE StartDate='$curr' AND ((CAST(StartTime as time) <= '$stime' AND CAST(EndTime as time) >= '$stime') OR (CAST(StartTime as time) <= '$etime' AND CAST(StartTime as time) >= '$stime') OR (CAST(StartTime as time) <= '$etime' AND CAST(EndTime as time) >= '$etime')) AND Type='$vtype' ";
			$result=mysql_query($query) or die('cannot get results!'.mysql_error());
			while($row = mysql_fetch_assoc($result)){
				if(!(isset($rooms[$row['RoomNo']]) && $rooms[$row['RoomNo']]['Priority']==$priority))
					$rooms[$row['RoomNo']] = $row;
			}
			$curr = date('Y-m-d', strtotime($curr.$n));
		}
	}
	elseif($mode=='2'){
		
		$n = " + 1 days";
		$curr = $date;
		$edate = date('Y-m-d', strtotime($edate.$n));

		while(strtotime($curr)<strtotime($edate)){
			$query = "SELECT * FROM venue WHERE StartDate='$curr' AND ((CAST(StartTime as time) <= '$stime' AND CAST(EndTime as time) >= '$stime') OR (CAST(StartTime as time) <= '$etime' AND CAST(StartTime as time) >= '$stime') OR (CAST(StartTime as time) <= '$etime' AND CAST(EndTime as time) >= '$etime')) AND Type='$vtype' ";
			$result=mysql_query($query) or die('cannot get results!'.mysql_error());
			while($row = mysql_fetch_assoc($result)){
				if(!(isset($rooms[$row['RoomNo']]) && $rooms[$row['RoomNo']]['Priority']==$priority))
					$rooms[$row['RoomNo']] = $row;
			}
			$curr = date('Y-m-d', strtotime($curr.$n));
		}
	}
}	
elseif(isset($_SESSION['mode'])&&isset($_SESSION['n'])&&isset($_SESSION['m'])&&isset($_SESSION['edate'])&&$_SESSION['mode']!=NULL&&$_SESSION['n']!=NULL&&$_SESSION['m']!=NULL&& $_SESSION['edate']!=NULL){
/*********************Recurring*************************/
$mode=$_SESSION['mode'];
$n=$_SESSION['n'];
$m=$_SESSION['m'];
$edate=$_SESSION['edate'];
	if($mode=='3'){
		
		$n = " + 1 days";
		$curr = $date;
		$edate = date('Y-m-d', strtotime($edate.$n));

		while(strtotime($curr)<strtotime($edate)){
			$query = "SELECT * FROM venue WHERE StartDate='$curr' AND ((CAST(StartTime as time) <= '$stime' AND CAST(EndTime as time) >= '$stime') OR (CAST(StartTime as time) <= '$etime' AND CAST(StartTime as time) >= '$stime') OR (CAST(StartTime as time) <= '$etime' AND CAST(EndTime as time) >= '$etime')) AND Type='$vtype' AND Recurring='no'";
			$result=mysql_query($query) or die('cannot get results!'.mysql_error());
			while($row = mysql_fetch_assoc($result)){
				if(!(isset($rooms[$row['RoomNo']]) && $rooms[$row['RoomNo']]['Priority']==$priority))
					$rooms[$row['RoomNo']] = $row;
			}
			$curr = date('Y-m-d', strtotime($curr.$n));
		}
	}
	
}
else{
	/*************Non-recurring******************/
	
	
	$query = "SELECT * FROM venue WHERE StartDate='$date' AND ((CAST(StartTime as time) <= '$stime' AND CAST(EndTime as time) >= '$stime') OR (CAST(StartTime as time) <= '$etime' AND CAST(StartTime as time) >= '$stime') OR (CAST(StartTime as time) <= '$etime' AND CAST(EndTime as time) >= '$etime')) AND Type='$vtype' ";
	$result=mysql_query($query) or die('cannot get results!'.mysql_error());

	while($row = mysql_fetch_assoc($result)){
		if(!(isset($rooms[$row['RoomNo']]) && $rooms[$row['RoomNo']]['Priority']==$priority))
			$rooms[$row['RoomNo']] = $row;
	}
}

/**************************fetching rooms finish*********************/


$content='<h1>'.(($priority==0)?'Student':'Faculty').'</h1>';
$content.='<div id="table" ><table style="width:100px;" class="setmain">';
$content.='<tr>';
$prev=0;

for($i=0;$i<3;$i++){
	$query = "SELECT * FROM all_venues WHERE Priority='$priority' AND BlockNo='".($i+1)."' AND Type='$vtype'";
	$result=mysql_query($query) or die('cannot get results!'.mysql_error());
	$allRooms = array();	
	while($row = mysql_fetch_assoc($result)){
		$allRooms[] = $row;
	}
	$content.='<td>
               <div id="'.chr($i+65).'"><h2> BLOCK'.($i+1).'</h2>
               </td></tr><tr><td>
			   <div>I Floor</div>
			   </td>';
	foreach($allRooms as $row){
	
		if($prev!=0 && intval($row['RoomNo']/100)>$prev)
			$content.='</tr><td><div>'.($prev+1).' Floor</div></td>';
		
		$content.='<td>
		<form method="post" action="venue.php" name="R'.$row['RoomNo'].'B'.$row['BlockNo'].'">
			<input type="hidden" name="roomno" value="'.$row['RoomNo'].'">
			<input type="hidden" name="blockno" value="'.$row['BlockNo'].'">
			<input type="hidden" name="forcetake" value="'.(((isset($rooms[$row['RoomNo']]) && $rooms[$row['RoomNo']]['BlockNo']==($i+1)) && $rooms[$row['RoomNo']]['Priority']!=$priority)?1:0).'">
		</form>
		
		<div id="';
			//$content.= ((isset($rooms[$row['RoomNo']]) && $rooms[$row['RoomNo']]['BlockNo']==($i+1))?'inactive':'active');
			if(isset($rooms[$row['RoomNo']]) && $rooms[$row['RoomNo']]['BlockNo']==($i+1) && $rooms[$row['RoomNo']]['Priority']!=0)
				$content.='inactive2';
			elseif(isset($rooms[$row['RoomNo']]) && $rooms[$row['RoomNo']]['BlockNo']==($i+1))
				$content.='inactive1';
			else
				$content.='active';
			
			
			$content.='"';
		if(!(isset($rooms[$row['RoomNo']]) && $rooms[$row['RoomNo']]['BlockNo']==($i+1))){
			$content.='onclick="form_send1(\'R'.$row['RoomNo'].'B'.$row['BlockNo'].'\');"';
			
		}
		else if((isset($rooms[$row['RoomNo']]) && $rooms[$row['RoomNo']]['BlockNo']==($i+1)) && $rooms[$row['RoomNo']]['Priority']!=$priority){
			$content.='onclick="form_send2(\'R'.$row['RoomNo'].'B'.$row['BlockNo'].'\');"';
			
		}
		else if((isset($rooms[$row['RoomNo']]) && $rooms[$row['RoomNo']]['BlockNo']==($i+1)) && $rooms[$row['RoomNo']]['Priority']==$priority){
			$content.='onclick="alert(\' Sorry!! You cannot book this venue\')"';
			
		}
		$content.='title="Capacity : '.$row['Capacity'].'"><span>'.$row['RoomNo'].'</span></div>
		
		<button onclick="bar('.$row['RoomNo'].','.$row['BlockNo'].')" >check</button>
		
		</td>';
		$prev = intval($row['RoomNo']/100);
	}

	$content.='<tr />';
}

$content.='</table></div>';

/*   Other quotas  */

for($j=0;$j<2;$j++){
	
	if($j==$priority)
		continue;
	
	$query = "SELECT * FROM venue WHERE StartDate='$date' AND ((CAST(StartTime as time) <= '$stime' AND CAST(EndTime as time) >= '$stime') AND (CAST(StartTime as time) <= '$etime' AND CAST(EndTime as time) >= '$etime')) AND Type='$vtype'";
	$result=mysql_query($query) or die('cannot get results!'.mysql_error());
	$roomsP = array();
	while($row = mysql_fetch_assoc($result)){
		$roomsP[$row['RoomNo']] = $row;
	}
	$content.='<h1>'.(($j==0)?'Student':'Faculty').'</h1>';

	$content.='<div id="table" ><table style="width:100px;" class="setmain">';
	$content.='<tr>';
	$prev=0;
	for($i=0;$i<3;$i++){
		$query = "SELECT * FROM all_venues WHERE Priority='$j' AND BlockNo='".($i+1)."' AND Type='$vtype'";
		$result=mysql_query($query) or die('cannot get results!'.mysql_error());
		$allRooms = array();	
		while($row = mysql_fetch_assoc($result)){
			$allRooms[] = $row;
		}
		$content.='<td>
				<div id="'.chr($i+65).'"><h2> BLOCK'.($i+1).'</h2>
				</td></tr><tr><td>
				<div>I Floor</div>
				</td>';
		foreach($allRooms as $row){
	
			if($prev!=0 && intval($row['RoomNo']/100)>$prev)
				$content.='</tr><td><div>'.($prev+1).' Floor</div></td>';
			$content.='<td>
			<form method="post" action="venue.php" name="R'.$row['RoomNo'].'B'.$row['BlockNo'].'">
			<input type="hidden" name="roomno" value="'.$row['RoomNo'].'">
			<input type="hidden" name="blockno" value="'.$row['BlockNo'].'">
			<input type="hidden" name="forcetake" value="0">

			</form>
		
			<div id="';
			//$content.= ((isset($rooms[$row['RoomNo']]) && $rooms[$row['RoomNo']]['BlockNo']==($i+1))?'inactive':'active');
			if(isset($rooms[$row['RoomNo']]) && $rooms[$row['RoomNo']]['BlockNo']==($i+1) && $rooms[$row['RoomNo']]['Priority']!=0)
				$content.='inactive2';
			elseif(isset($rooms[$row['RoomNo']]) && $rooms[$row['RoomNo']]['BlockNo']==($i+1))
				$content.='inactive1';
			else
				$content.='active';
			
			
			$content.='"';
			if(!(isset($rooms[$row['RoomNo']]) && $rooms[$row['RoomNo']]['BlockNo']==($i+1))){
				$content.='onclick="form_send1(\'R'.$row['RoomNo'].'B'.$row['BlockNo'].'\');"';
			}
			elseif((isset($rooms[$row['RoomNo']]) && $rooms[$row['RoomNo']]['BlockNo']==($i+1))){
				$content.='onclick="alert(\' Sorry!! You can\'t book this venue\');"';
			}
			$content.='title="Capacity : '.$row['Capacity'].'"><span>'.$row['RoomNo'].'</span></div>
			
			<button onclick="bar('.$row['RoomNo'].','.$row['BlockNo'].')" >check</button>
			
			</td>';
			$prev = intval($row['RoomNo']/100);
		}

		$content.='<tr />';
	}

$content.='</table></div>';
	
	
}

}

}
/*******************************************************************************************************/


/***********************************for bar view*************************************************/
if(isset($_POST['rno']) && isset($_POST['bno']) && $_POST['rno']!=null && $_POST['bno']!=null){
	
$rno = $_POST['rno'];
$bno = $_POST['bno'];
mysql_connect("localhost","bora.cs14","bora@678") or die("Cannot connect to databse");
mysql_select_db("main") or die("Cannot find database");

$query = "SELECT * FROM venue WHERE RoomNo='$rno' AND BlockNo='$bno' AND StartDate='$date' ";
$result=mysql_query($query) or die('cannot get results!'.mysql_error());

$vens = array();

while($row = mysql_fetch_assoc($result)){
	$vens[]= $row;
}
$barContent='<h1>Event timings</h1><hr>';
if(count($vens)!=0){
$barContent.= '<table style="margin:0px">';
$barContent.= '<tr>';
$barContent.= '<th >Name </th>';
for($i=0;$i<24;$i++){
	
	$barContent.= '<th>'.$i.'</th>';
}
$barContent.= '</tr>';


foreach($vens as $row){
	$barContent.= '<tr>';
	$barContent.= '<td class="name">'.$row['EventName'].'&nbsp;&nbsp;&nbsp;</td>';
	for($i=0;$i<24;$i++){
		$barContent.= '<td>';
		$start = intval(explode(":",$row['StartTime'])[0]);
		$end = intval(explode(":",$row['EndTime'])[0]);
		if($start <= $i && $end > $i){
			$barContent.= '<div id="bar"></div>';
		}
		
		$barContent.= '</td>';
	}
	$barContent.= '</tr>';
}

$barContent.= '</table>';	
}
else $barContent = 'No events today';	

}

?>	 


<!DOCTYPE html>
<html class=" js rgba multiplebgs backgroundsize borderradius boxshadow textshadow opacity cssgradients csstransitions generatedcontent js rgba multiplebgs backgroundsize borderradius boxshadow textshadow opacity cssgradients csstransitions generatedcontent" lang="en"><!--<![endif]--><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Evento</title>

<meta name="robots" content="noindex,follow">
<link  href="notify.css" rel="stylesheet">
<link rel="icon" href="favicon.ico" type="image/x-icon" />



	<script type="text/javascript">
		/* <![CDATA[ */
		function addLoadEvent(func) {
			var oldonload = window.onload;
			if (typeof window.onload != 'function') {
				window.onload = func;
			} else {
				window.onload = function () {
					oldonload();
					func();
				}
			}
		}
		/* ]]> */
	</script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<link  href="./docs/css/datepicker.css" rel="stylesheet">
<script src="./docs/js/datepicker.js"></script>

<script>
$(document).ready(function(){
    jQuery("#A").click(function(){
        if(jQuery('.floorA').is(":visible"))
        jQuery('.floorA').hide();
        else
        jQuery(".floorA").show();
    });
	jQuery("#B").click(function(){
        if(jQuery('.floorB').is(":visible"))
        jQuery('.floorB').hide();
        else
        jQuery(".floorB").show();
    });
	jQuery("#C").click(function(){
        if(jQuery('.floorC').is(":visible"))
        jQuery('.floorC').hide();
        else
        jQuery('.floorC').show();
    });
	$('[data-toggle="datepicker"]').datepicker({
		format: 'yyyy-mm-dd'
	});
		$('#textdat').attr("readonly",true);
});
</script>

	<style>

table{
				width:100%;
				border-collapse: collapse;
			}
			th,td{
				width:3.75%;
				height:10px;
				padding:0px;
				padding-top:4px;
				padding-left:10px;
				text-align:center;
			}
			
			.name{
				width:10%;
				text-align:right;	
			}

			#bar {

				width:100%;
				height:15px;
				background-color:#FCCA15;
				text-align:center;

			}
			
			hr {
				border: 0;
				height: 1px;
				background-image: linear-gradient(to right, rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.75), rgba(0, 0, 0, 0));
			}
	


</style>

	<link rel="stylesheet" id="all-css-0" href="./eventoCSS/saved_resource.css" type="text/css" media="all">


<link rel="stylesheet" id="all-css-6" href="./eventoCSS/saved_resource(1).css" type="text/css" media="all">

<link href="https://fonts.googleapis.com/css?family=Cutive" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet" type="text/css">
<link rel="stylesheet" id="all-css-8" href="./eventoCSS/saved_resource(2).css" type="text/css" media="all">
<script type="text/javascript">
/* <![CDATA[ */
var LoggedOutFollow = {"invalid_email":"Your subscription did not succeed, please try again with a valid email address."};
/* ]]> */
</script>
<script type="text/javascript" src="./eventoCSS/saved_resource(3).css"></script>

<!--[if lt IE 8]>
<link rel='stylesheet' id='highlander-comments-ie7-css'  href='https://s1.wp.com/wp-content/mu-plugins/highlander-comments/style-ie7.css?m=1351637563h&#038;ver=20110606' type='text/css' media='all' />
<![endif]-->

 
<meta name="generator" content="WordPress.com">



<!-- Jetpack Open Graph Tags -->
<meta property="og:type" content="article">
<meta property="og:title" content="Calendar">
<meta property="og:url" content="https://eventbritevenuedemo.wordpress.com/calendar/">
<meta property="og:description" content="Visit the post for more.">
<meta property="article:published_time" content="2013-09-10T19:46:38+00:00">
<meta property="article:modified_time" content="2013-09-10T19:46:38+00:00">
<meta property="og:site_name" content="Eventbrite Multi">
<meta property="og:image" content="https://s0.wp.com/i/blank.jpg">
<meta property="og:locale" content="en_US">
<meta name="twitter:site" content="@wordpressdotcom">
<meta name="twitter:card" content="summary">
<meta name="twitter:description" content="Visit the post for more.">
<meta property="fb:app_id" content="249643311490">
<meta property="article:publisher" content="https://www.facebook.com/WordPresscom">



<link rel="stylesheet" type="text/css" href="venue.css">



		<style type="text/css">
			.recentcomments a {
				display: inline !important;
				padding: 0 !important;
				margin: 0 !important;
			}

			table.recentcommentsavatartop img.avatar, table.recentcommentsavatarend img.avatar {
				border: 0px;
				margin: 0;
			}

			table.recentcommentsavatartop a, table.recentcommentsavatarend a {
				border: 0px !important;
				background-color: transparent !important;
			}

			td.recentcommentsavatarend, td.recentcommentsavatartop {
				padding: 0px 0px 1px 0px;
				margin: 0px;
			}

			td.recentcommentstextend {
				border: none !important;
				padding: 0px 0px 2px 10px;
			}

			.rtl td.recentcommentstextend {
				padding: 0px 10px 2px 0px;
			}

			td.recentcommentstexttop {
				border: none;
				padding: 0px 0px 0px 10px;
			}

			.rtl td.recentcommentstexttop {
				padding: 0px 10px 0px 0px; 
			}
		</style>
		<meta name="application-name" content="Eventbrite Multi"><meta name="msapplication-window" content="width=device-width;height=device-height"><meta name="msapplication-tooltip" content="Connect to Eventbrite with your WordPress.com theme"><meta name="msapplication-task" content="name=Subscribe;action-uri=https://eventbritevenuedemo.wordpress.com/feed/;icon-uri=https://s2.wp.com/i/favicon.ico"><meta name="msapplication-task" content="name=Sign up for a free blog;action-uri=http://wordpress.com/signup/;icon-uri=https://s2.wp.com/i/favicon.ico"><meta name="msapplication-task" content="name=WordPress.com Support;action-uri=http://support.wordpress.com/;icon-uri=https://s2.wp.com/i/favicon.ico"><meta name="msapplication-task" content="name=WordPress.com Forums;action-uri=http://forums.wordpress.com/;icon-uri=https://s2.wp.com/i/favicon.ico"><meta name="title" content="Calendar | Eventbrite Multi on WordPress.com">
<meta name="description" content="Connect to Eventbrite with your WordPress.com theme">
		<style type="text/css">
					header .logo-text h1,
			header .logo-text h5 {
				color: #fff;
			}
			#matter{
				color:#e77e23;
			}
				</style>
				<style type="text/css" id="eventbrite-header-css">
		header[role=banner] {
			background: url(cropped-cropped-ola-bread-tray-1.jpg) top center no-repeat;
			background-size: cover;
		}
		</style>
		<style type="text/css" id="custom-background-css">
body.custom-background { background-image: url('bg-main.png'); background-repeat: repeat; background-position: top left; background-attachment: scroll; }
</style>
<style type="text/css" id="syntaxhighlighteranchor"></style>
			<style id="demo-site-activation">
				#infinite-footer {
					display: none !important;
				}

				@media screen and (max-width: 600px) {
					.demosite-activate {
						position: absolute;
					}
				}
			</style>
					<style id="demo-site-activation-logged-out">
				
				@media screen and (max-width: 620px) {
					html {
						margin-top: 100px !important;
					}
				}
				@media screen and (max-width: 600px) {
					.demosite-activate {
						position: absolute;
					}
				}
			</style>
		</head>

<body class="page page-id-108 page-template-default custom-background mp6 customizer-styles-applied template-calendar highlander-enabled highlander-light demo-site" data-pinterest-extension-installed="cr1.39.1">
		<header role="banner">
		<div class="container">
			<div class="logo-row">
												<a class="logo-text">
					<h1 style="font-family:Cutive;">Evento</h1>
					<h5 style="font-family:Raleway;">Connect to Evento with your Webmail facilities</h5>
					<br>
				</a>
			</div>
		</div>
	</header>
	<br>

	<section role="main" class="main-container">
		<div id="site-container" class="container">
			<nav class="menu">
			<ul id="menu-main-menu" class="menu">
	<li id="menu-item-112" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-108 current_page_item menu-item-112"><a>All Events</a>
		<ul class="sub-menu">
		<li id="menu-item-122" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-122"><a href="month.php">Month View</a></li>
		<li id="menu-item-117" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-117"><a href="week.php">Week View</a></li>
		<li id="menu-item-116" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-116"><a href="day.php">Day View</a></li>
		</ul>
	</li>
	<li id="menu-item-151" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-151"><a>My Schedule</a>
		<ul class="sub-menu">
		<li id="menu-item-122" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-122"><a href="mymonth.php">Month View</a></li>
		<li id="menu-item-117" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-117"><a href="myweek.php">Week View</a></li>
		<li id="menu-item-116" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-116"><a href="myday.php">Day View</a></li>
		</ul>
	</li>
	<li id="menu-item-111" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-111"><a href="myevents.php">My Events</a></li>
	<li id="menu-item-114" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-114"><a href="venue.php">Venues</a>

	</li>
	<li id="menu-item-113" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-113"><a href="compose.php">Compose</a></li>
	<li id="menu-item-113" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-113" style="float:right;"><a href="logout.php"><img src="logout.png"></a></li>
	<li id="menu-item-113" class="dropdown" style="float:right;"><a onclick="myFunction()" class="dropbtn"><span onclick="myFunction()"><img src="notification.png"></a></li>
	<li id="menu-item-113" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-113" style="float:right; border-right: 1px solid #666;"><a href="search.php"><img src="Search.png"></span></a></li>
	</ul>
	</nav>
	
	<div id="myDropdown" class="dropdown-content">
    <br />
	<p style="text-align:center;">NOTIFICATIONS</p>
	<hr style="margin:6px;border-top: 1px solid black;"/>
	<?php
		error_reporting(0);
		session_start();
		
		mysql_connect("localhost","bora.cs14","bora@678") or die("Cannot connect to databse");
		mysql_select_db($_SESSION['User']) or die("Cannot find database");
		$query = "SELECT * FROM notifications ORDER BY Sno DESC";
		$result = mysql_query($query) or die('cannot get results!');
		$notify = array();

		while($row = mysql_fetch_assoc($result)) {
			$notify[] = $row['Data'];
		}
		$flag=1;
	foreach($notify as $data){
		if($flag){
				echo '<b id="grey">'.$data.'</b>';
				$flag=!$flag;
		}
		else{
			  echo '<b id="white" >'.$data.'</b>';
			  $flag=!$flag;
		}
		
	}
		
	?>
	</div>
	<script>
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {

    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>


<div class="row">
	<div class="span12">

<div id="filter" align="center">
<br />
<form id="filter" name="filter" action="venue.php" method="post">
Capacity: &nbsp <input type="text" name="capacity"  id="textcap"  value="<?php if(isset($_POST['capacity'])){echo $_POST['capacity'];}?>"/>
&nbsp Timing : &nbsp <input type="time" name="stime"  id="text"value="<?php echo $_POST['stime'];?>"/>
&nbsp  to &nbsp <input type="time" name="etime" id="text" value="<?php echo $_POST['etime'];?>" />
&nbsp  Type &nbsp <select style="height:35px" name="vtype" > 
<option <?php if(isset($_POST['vtype'])&&$_POST['vtype']=='lab') echo ' selected="selected"'; ?> value="lab">Lab</option>
<option <?php if(isset($_POST['vtype'])&&$_POST['vtype']=='ClassRoom') echo ' selected="selected"'; ?> value="ClassRoom">ClassRoom</option>
<option <?php if(isset($_POST['vtype'])&&$_POST['vtype']=='cc') echo 'selected="selected"'; ?> value="cc">Computer Center</option>
 </select>
&nbsp; 
<input type="text"  id="textdat" name="date" data-toggle="datepicker" placeholder="yyyy-mm-dd" value="<?php if(isset($_POST['date'])) echo "$date"?>">

&nbsp;<br /><br />


&nbsp <input type="submit" value="Filter" id="text" />
<input id="rno" name="rno" type=hidden>
<input id="bno" name="bno" type=hidden>
</form id="filter" >
<br /></div>
<?php echo $barContent;?>
<hr >
<?php echo $content;?><br/><br />
<script>
function bar(a,b){
	document.getElementById("rno").value = a;
	document.getElementById("bno").value = b;

	document.forms['filter'].submit();
	//alert('Stop');
}
</script>

<?php

/*********************************** Create venue or update venue *********************/
if(isset($_POST['roomno'])&&isset($_POST['blockno']) && isset($_POST['forcetake']) &&$_SESSION['EventId']!=null&&$_SESSION['stime']!=null&&$_SESSION['etime']!=null&&$_SESSION['sdate']!=null){
$roomNo = $_POST['roomno'];
$blockNo = $_POST['blockno'];
$eventId = $_SESSION['EventId'];
$stime = $_SESSION['stime'];
$etime = $_SESSION['etime'];
$sdate = $_SESSION['sdate'];
$day = explode("-",$sdate)[2];
$mon = explode("-",$sdate)[1];
$year = explode("-",$sdate)[0];
$ven = "R".$roomNo." ".chr($blockNo+64);
$eventname = $_SESSION['EventName'];

/* Get priority from adjlist */
mysql_connect("localhost","bora.cs14","bora@678") or die("Cannot connect to databse");
mysql_select_db("main") or die("Cannot find database");

$query = "SELECT Priority FROM adjlist WHERE Name='".$_SESSION['User']."'";
$result=mysql_query($query) or die('cannot get results!'.mysql_error());
$row = mysql_fetch_assoc($result);
$priority = $row['Priority']; 
//echo $priority."  ".$_SESSION['User'];


mysql_connect("localhost","bora.cs14","bora@678") or die("Cannot connect to databse");
mysql_select_db("main") or die("Cannot find database");

$stim = rtrim($stime, "0");
$stim = rtrim($stim, ":");
$etim = rtrim($etime, "0");
$etim = rtrim($etim, ":");
/* Update event info */
$query = "UPDATE all_events SET StartTime='$stim',EndTime='$etim',Day='$day',Month='$mon',Year='$year',Venue='$ven' WHERE Sno='$eventId'";
$result=mysql_query($query) or die('cannot get results!'.mysql_error());


/*  Get venue details  */
$query = "SELECT * FROM all_venues WHERE BlockNo='$blockNo' AND RoomNo='$roomNo'";
$result=mysql_query($query) or die('cannot get results!'.mysql_error());
$roomInfo = mysql_fetch_assoc($result);



$capacity = $roomInfo['Capacity'];

$type = $roomInfo['Type'];
$roomId = $roomInfo['Id'];

if($_POST['forcetake']==1){
	
	/*  Delete and create venue  */
	$removing = array();
	if(isset($_SESSION['mode'])&&isset($_SESSION['n'])&&isset($_SESSION['edate'])&&$_SESSION['mode']!=NULL&&$_SESSION['n']!=NULL&& $_SESSION['edate']!=NULL){
	$mode=$_SESSION['mode'];
	$day=$_SESSION['n'];
	$month=$_SESSION['m'];
	$edate=$_SESSION['edate'];
		if($mode=="0"){
			$n=" + ".$day." days";
			$curr = $sdate;
			$edate = date('Y-m-d', strtotime($edate.$n));
			while(strtotime($curr)<strtotime($edate)){
				
				$query = "SELECT * FROM venue WHERE BlockNo='$blockNo' AND RoomNo='$roomNo' AND StartDate='$curr' AND ((CAST(StartTime as time) <= '$stime' AND CAST(EndTime as time) >= '$stime') OR (CAST(StartTime as time) <= '$etime' AND CAST(StartTime as time) >= '$stime') OR (CAST(StartTime as time) <= '$etime' AND CAST(EndTime as time) >= '$etime')) AND Type='$type'";
				$result=mysql_query($query) or die('cannot get results!'.mysql_error());
	
				while($row = mysql_fetch_assoc($result)){
					$removing[] = $row;
				}
				$query = "DELETE FROM venue WHERE BlockNo='$blockNo' AND RoomNo='$roomNo' AND StartDate='$curr' AND ((CAST(StartTime as time) <= '$stime' AND CAST(EndTime as time) >= '$stime') OR (CAST(StartTime as time) <= '$etime' AND CAST(StartTime as time) >= '$stime') OR (CAST(StartTime as time) <= '$etime' AND CAST(EndTime as time) >= '$etime')) AND Type='$type'";
				$result=mysql_query($query) or die('cannot get results!'.mysql_error());
				$curr = date('Y-m-d', strtotime($curr.$n));
			}
			
			
			
		}
		elseif($mode=='1'){
			
			$n = " + 1 days";
			$curr = $sdate;
			$edate = date('Y-m-d', strtotime($edate.$n));

			while(strtotime($curr)<strtotime($edate)){
				if(''.date("w",strtotime($curr))==$day){
					$query = "SELECT * FROM venue WHERE BlockNo='$blockNo' AND RoomNo='$roomNo' AND StartDate='$curr' AND ((CAST(StartTime as time) <= '$stime' AND CAST(EndTime as time) >= '$stime') OR (CAST(StartTime as time) <= '$etime' AND CAST(StartTime as time) >= '$stime') OR (CAST(StartTime as time) <= '$etime' AND CAST(EndTime as time) >= '$etime')) AND Type='$type'";
					$result=mysql_query($query) or die('cannot get results!'.mysql_error());
	
					while($row = mysql_fetch_assoc($result)){
						$removing[] = $row;
					}
					$query = "DELETE FROM venue WHERE BlockNo='$blockNo' AND RoomNo='$roomNo' AND StartDate='$curr' AND ((CAST(StartTime as time) <= '$stime' AND CAST(EndTime as time) >= '$stime') OR (CAST(StartTime as time) <= '$etime' AND CAST(StartTime as time) >= '$stime') OR (CAST(StartTime as time) <= '$etime' AND CAST(EndTime as time) >= '$etime')) AND Type='$type'";
					$result=mysql_query($query) or die('cannot get results!'.mysql_error());
				
				}
				$curr = date('Y-m-d', strtotime($curr.$n));
			}
			
			
		}
		elseif($mode=='2'){
			
			$n = " + 1 days";
			$curr = $sdate;
			$edate = date('Y-m-d', strtotime($edate.$n));

			while(strtotime($curr)<strtotime($edate)){
				if(''.explode("-",$curr)[2]==$day){
					$query = "SELECT * FROM venue WHERE BlockNo='$blockNo' AND RoomNo='$roomNo' AND StartDate='$curr' AND ((CAST(StartTime as time) <= '$stime' AND CAST(EndTime as time) >= '$stime') OR (CAST(StartTime as time) <= '$etime' AND CAST(StartTime as time) >= '$stime') OR (CAST(StartTime as time) <= '$etime' AND CAST(EndTime as time) >= '$etime')) AND Type='$type'";
					$result=mysql_query($query) or die('cannot get results!'.mysql_error());
					while($row = mysql_fetch_assoc($result)){
						$removing[] = $row;
					}
					$query = "DELETE FROM venue WHERE BlockNo='$blockNo' AND RoomNo='$roomNo' AND StartDate='$curr' AND ((CAST(StartTime as time) <= '$stime' AND CAST(EndTime as time) >= '$stime') OR (CAST(StartTime as time) <= '$etime' AND CAST(StartTime as time) >= '$stime') OR (CAST(StartTime as time) <= '$etime' AND CAST(EndTime as time) >= '$etime')) AND Type='$type'";
					$result=mysql_query($query) or die('cannot get results!'.mysql_error());
				}
				$curr = date('Y-m-d', strtotime($curr.$n));
			}
			
			
			
		}
	}	
	elseif(isset($_SESSION['mode'])&&isset($_SESSION['n'])&&isset($_SESSION['m'])&&isset($_SESSION['edate'])&&$_SESSION['mode']!=NULL&&$_SESSION['n']!=NULL&&$_SESSION['m']!=NULL&& $_SESSION['edate']!=NULL){

		$mode=$_SESSION['mode'];
		$n=$_SESSION['n'];
		$m=$_SESSION['m'];
		$edate=$_SESSION['edate'];
		if($mode=='3'){
			
			$n = " + 1 days";
			$curr = $sdate;
			$edate = date('Y-m-d', strtotime($edate.$n));

			while(strtotime($curr)<strtotime($edate)){
				if(''.explode("-",$curr)[1]==$month && ''.explode("-",$curr)[2]==$day){
					$query = "SELECT * FROM venue WHERE BlockNo='$blockNo' AND RoomNo='$roomNo' AND StartDate='$curr' AND ((CAST(StartTime as time) <= '$stime' AND CAST(EndTime as time) >= '$stime') OR (CAST(StartTime as time) <= '$etime' AND CAST(StartTime as time) >= '$stime') OR (CAST(StartTime as time) <= '$etime' AND CAST(EndTime as time) >= '$etime')) AND Type='$type'";
					$result=mysql_query($query) or die('cannot get results!'.mysql_error());
					while($row = mysql_fetch_assoc($result)){
						$removing[] = $row;
					}
					$query = "DELETE FROM venue WHERE BlockNo='$blockNo' AND RoomNo='$roomNo' AND StartDate='$curr' AND ((CAST(StartTime as time) <= '$stime' AND CAST(EndTime as time) >= '$stime') OR (CAST(StartTime as time) <= '$etime' AND CAST(StartTime as time) >= '$stime') OR (CAST(StartTime as time) <= '$etime' AND CAST(EndTime as time) >= '$etime')) AND Type='$type'";
					$result=mysql_query($query) or die('cannot get results!'.mysql_error());
				}
				$curr = date('Y-m-d', strtotime($curr.$n));
			}
			
		}
			
	}
	
	
	
	
	else{
	
		$query = "SELECT * FROM venue WHERE BlockNo='$blockNo' AND RoomNo='$roomNo' AND StartDate='$sdate' AND ((CAST(StartTime as time) <= '$stime' AND CAST(EndTime as time) >= '$stime') OR (CAST(StartTime as time) <= '$etime' AND CAST(StartTime as time) >= '$stime') OR (CAST(StartTime as time) <= '$etime' AND CAST(EndTime as time) >= '$etime')) AND Type='$type'";
		$result=mysql_query($query) or die('cannot get results!'.mysql_error());
		
		while($row = mysql_fetch_assoc($result)){
			$removing[] = $row;
		}
		$query = "DELETE FROM venue WHERE BlockNo='$blockNo' AND RoomNo='$roomNo' AND StartDate='$sdate' AND ((CAST(StartTime as time) <= '$stime' AND CAST(EndTime as time) >= '$stime') OR (CAST(StartTime as time) <= '$etime' AND CAST(StartTime as time) >= '$stime') OR (CAST(StartTime as time) <= '$etime' AND CAST(EndTime as time) >= '$etime')) AND Type='$type'";
		$result=mysql_query($query) or die('cannot get results!'.mysql_error());
	}
	
	foreach($removing as $row){
		$eid = $row['Event'];
		$query = "DELETE FROM all_events WHERE Sno='$eid'";
		$result=mysql_query($query) or die('cannot get results!'.mysql_error());
	}
	
	
	
	/* Create venue */
	
	if(isset($_SESSION['mode'])&&isset($_SESSION['n'])&&isset($_SESSION['User'])&&isset($_SESSION['edate'])&&$_SESSION['mode']!=NULL&&$_SESSION['n']!=NULL&& $_SESSION['edate']!=NULL){
	$mode=$_SESSION['mode'];
	$day=$_SESSION['n'];
	$month=$_SESSION['m'];
	$edate=$_SESSION['edate'];
		if($mode=="0"){
			$n=" + ".$day." days";
			$curr = $sdate;
			$edate = date('Y-m-d', strtotime($edate.$n));
			while(strtotime($curr)<strtotime($edate)){
				
				$query = "INSERT INTO venue(RoomNo,BlockNo,Capacity,Type,StartTime,EndTime,Event,StartDate,Priority,EventName) VALUES('$roomNo','$blockNo','$capacity','$type','$stime','$etime','$eventId','$curr','$priority','$eventname')";
				$result=mysql_query($query) or die('cannot get results!'.mysql_error());
				$curr = date('Y-m-d', strtotime($curr.$n));
			}
			
			$query = "UPDATE all_events SET Venue='$ven' WHERE Sno='$eventId'";
			$result=mysql_query($query) or die('cannot get results!'.mysql_error());
			
		}
		elseif($mode=='1'){
			
			$n = " + 1 days";
			$curr = $sdate;
			$edate = date('Y-m-d', strtotime($edate.$n));

			while(strtotime($curr)<strtotime($edate)){
				if(''.date("w",strtotime($curr))==$day){
				$query = "INSERT INTO venue(RoomNo,BlockNo,Capacity,Type,StartTime,EndTime,Event,StartDate,Priority,EventName) VALUES('$roomNo','$blockNo','$capacity','$type','$stime','$etime','$eventId','$curr','$priority','$eventname')";
					$result=mysql_query($query) or die('cannot get results!'.mysql_error());
				
				}
				$curr = date('Y-m-d', strtotime($curr.$n));
			}
			$query = "UPDATE all_events SET Venue='$ven' WHERE Sno='$eventId'";
			$result=mysql_query($query) or die('cannot get results!'.mysql_error());
			
		}
		elseif($mode=='2'){
			
			$n = " + 1 days";
			$curr = $sdate;
			$edate = date('Y-m-d', strtotime($edate.$n));

			while(strtotime($curr)<strtotime($edate)){
				if(''.explode("-",$curr)[2]==$day){
				$query = "INSERT INTO venue(RoomNo,BlockNo,Capacity,Type,StartTime,EndTime,Event,StartDate,Priority,EventName) VALUES('$roomNo','$blockNo','$capacity','$type','$stime','$etime','$eventId','$curr','$priority','$eventname')";
					$result=mysql_query($query) or die('cannot get results!'.mysql_error());
				
				}
				$curr = date('Y-m-d', strtotime($curr.$n));
			}
			$query = "UPDATE all_events SET Venue='$ven' WHERE Sno='$eventId'";
			$result=mysql_query($query) or die('cannot get results!'.mysql_error());
			
			
		}
		$_SESSION['EventId']=NULL;
			$_SESSION['stime']=NULL;
			$_SESSION['etime']=NULL;
			$_SESSION['sdate']=NULL;
			$_SESSION['mode']=NULL;
			$_SESSION['n']=NULL;
			$_SESSION['m']=NULL;
			$_SESSION['edate']=NULL;
		header("Location: month.php");
	}	
	elseif(isset($_SESSION['mode'])&&isset($_SESSION['n'])&&isset($_SESSION['m'])&&isset($_SESSION['edate'])&&$_SESSION['mode']!=NULL&&$_SESSION['n']!=NULL&&$_SESSION['m']!=NULL&& $_SESSION['edate']!=NULL){

		$mode=$_SESSION['mode'];
		$n=$_SESSION['n'];
		$m=$_SESSION['m'];
		$edate=$_SESSION['edate'];	
		if($mode=='3'){
			
			$n = " + 1 days";
			$curr = $sdate;
			$edate = date('Y-m-d', strtotime($edate.$n));

			while(strtotime($curr)<strtotime($edate)){
				if(''.explode("-",$curr)[1]==$month && ''.explode("-",$curr)[2]==$day){
				$query = "INSERT INTO venue(RoomNo,BlockNo,Capacity,Type,StartTime,EndTime,Event,StartDate,Priority,EventName) VALUES('$roomNo','$blockNo','$capacity','$type','$stime','$etime','$eventId','$curr','$priority','$eventname')";
					$result=mysql_query($query) or die('cannot get results!'.mysql_error());
				}
				$curr = date('Y-m-d', strtotime($curr.$n));
			}
			$query = "UPDATE all_events SET Venue='$ven' WHERE Sno='$eventId'";
			$result=mysql_query($query) or die('cannot get results!'.mysql_error());
		}
			$_SESSION['EventId']=NULL;
			$_SESSION['stime']=NULL;
			$_SESSION['etime']=NULL;
			$_SESSION['sdate']=NULL;
			$_SESSION['mode']=NULL;
			$_SESSION['n']=NULL;
			$_SESSION['m']=NULL;
			$_SESSION['edate']=NULL;
		header("Location: month.php");
	}
	else{
		$query = "INSERT INTO venue(RoomNo,BlockNo,Capacity,Type,StartTime,EndTime,Event,StartDate,Priority,EventName) VALUES('$roomNo','$blockNo','$capacity','$type','$stime','$etime','$eventId','$curr','$priority','$eventname')";
		$result=mysql_query($query) or die('cannot get results!'.mysql_error());

		$query = "UPDATE all_events SET Venue='$ven' WHERE Sno='$eventId'";
		$result=mysql_query($query) or die('cannot get results!'.mysql_error());
		echo 'Succesfull';
			$_SESSION['EventId']=NULL;
			$_SESSION['stime']=NULL;
			$_SESSION['etime']=NULL;
			$_SESSION['sdate']=NULL;
		header("Location: month.php");
	}
	
}
else{
	
	
	
	/* Create venue */


	

	if(isset($_SESSION['mode']) && isset($_SESSION['n'])  && isset( $_SESSION['edate']) && $_SESSION['mode']!=NULL && $_SESSION['n']!=NULL  && $_SESSION['edate']!=NULL){
	$mode=$_SESSION['mode'];
	$day=$_SESSION['n'];
	$month=$_SESSION['m'];
	$edate=$_SESSION['edate'];
		if($mode=="0"){
			
			$curr = $sdate;
			$n=" + ".$day." days";
			$edate = date('Y-m-d', strtotime($edate.$n));
			while(strtotime($curr)<strtotime($edate)){
				
				$query = "INSERT INTO venue(RoomNo,BlockNo,Capacity,Type,StartTime,EndTime,Event,StartDate,Priority,EventName) VALUES('$roomNo','$blockNo','$capacity','$type','$stime','$etime','$eventId','$curr','$priority','$eventname')";
				$result=mysql_query($query) or die('cannot get results!'.mysql_error());
				$curr = date('Y-m-d', strtotime($curr.$n));
			}
			
			$query = "UPDATE all_events SET Venue='$ven' WHERE Sno='$eventId'";
			$result=mysql_query($query) or die('cannot get results!'.mysql_error());
			
		}
		elseif($mode=='1'){
			
			$n = " + 1 days";
			$curr = $sdate;
			$edate = date('Y-m-d', strtotime($edate.$n));

			while(strtotime($curr)<strtotime($edate)){
				if(''.date("w",strtotime($curr))==$day){
				$query = "INSERT INTO venue(RoomNo,BlockNo,Capacity,Type,StartTime,EndTime,Event,StartDate,Priority,EventName) VALUES('$roomNo','$blockNo','$capacity','$type','$stime','$etime','$eventId','$curr','$priority','$eventname')";
					$result=mysql_query($query) or die('cannot get results!'.mysql_error());
				
				}
				$curr = date('Y-m-d', strtotime($curr.$n));
			}
			$query = "UPDATE all_events SET Venue='$ven' WHERE Sno='$eventId'";
			$result=mysql_query($query) or die('cannot get results!'.mysql_error());
			
		}
		elseif($mode=='2'){
			
			$n = " + 1 days";
			$curr = $sdate;
			$edate = date('Y-m-d', strtotime($edate.$n));

			while(strtotime($curr)<strtotime($edate)){
				if(''.explode("-",$curr)[2]==$day){
				$query = "INSERT INTO venue(RoomNo,BlockNo,Capacity,Type,StartTime,EndTime,Event,StartDate,Priority,EventName) VALUES('$roomNo','$blockNo','$capacity','$type','$stime','$etime','$eventId','$curr','$priority','$eventname')";
					$result=mysql_query($query) or die('cannot get results!'.mysql_error());
				
				}
				$curr = date('Y-m-d', strtotime($curr.$n));
			}
			$query = "UPDATE all_events SET Venue='$ven' WHERE Sno='$eventId'";
			$result=mysql_query($query) or die('cannot get results!'.mysql_error());
			
			
		}
		$_SESSION['EventId']=NULL;
		$_SESSION['stime']=NULL;
		$_SESSION['etime']=NULL;
		$_SESSION['sdate']=NULL;
		$_SESSION['mode']=NULL;
		$_SESSION['n']=NULL;
		$_SESSION['m']=NULL;
		$_SESSION['edate']=NULL;
		
		header("Location: month.php");	
	}	
	elseif(isset($_SESSION['mode'])&&isset($_SESSION['n'])&&isset($_SESSION['m'])&&isset($_SESSION['edate'])&&$_SESSION['mode']!=NULL&&$_SESSION['n']!=NULL&&$_SESSION['m']!=NULL&& $_SESSION['edate']!=NULL){

		$mode=$_SESSION['mode'];
		$n=$_SESSION['n'];
		$m=$_SESSION['m'];
		$edate=$_SESSION['edate'];	
		if($mode=='3'){
			
			$n = " + 1 days";
			$curr = $sdate;
			$edate = date('Y-m-d', strtotime($edate.$n));

			while(strtotime($curr)<strtotime($edate)){
				if(''.explode("-",$curr)[1]==$month && ''.explode("-",$curr)[2]==$day){
				$query = "INSERT INTO venue(RoomNo,BlockNo,Capacity,Type,StartTime,EndTime,Event,StartDate,Priority,EventName) VALUES('$roomNo','$blockNo','$capacity','$type','$stime','$etime','$eventId','$curr','$priority','$eventname')";
					$result=mysql_query($query) or die('cannot get results!'.mysql_error());
				}
				$curr = date('Y-m-d', strtotime($curr.$n));
			}
			$query = "UPDATE all_events SET Venue='$ven' WHERE Sno='$eventId'";
			$result=mysql_query($query) or die('cannot get results!'.mysql_error());
		}
			$_SESSION['EventId']=NULL;
			$_SESSION['stime']=NULL;
			$_SESSION['etime']=NULL;
			$_SESSION['sdate']=NULL;
			$_SESSION['mode']=NULL;
			$_SESSION['n']=NULL;
			$_SESSION['m']=NULL;
			$_SESSION['edate']=NULL;
		header("Location: month.php");	
	}
	else{
		
				$query = "INSERT INTO venue(RoomNo,BlockNo,Capacity,Type,StartTime,EndTime,Event,StartDate,Priority,EventName) VALUES('$roomNo','$blockNo','$capacity','$type','$stime','$etime','$eventId','$sdate','$priority','$eventname')";
		$result=mysql_query($query) or die('cannot get results!'.mysql_error());

		$query = "UPDATE all_events SET Venue='$ven' WHERE Sno='$eventId'";
		$result=mysql_query($query) or die('cannot get results!'.mysql_error());
		echo 'Succesfull';
			$_SESSION['EventId']=NULL;
			$_SESSION['stime']=NULL;
			$_SESSION['etime']=NULL;
			$_SESSION['sdate']=NULL;
		header("Location: month.php");
	}


	
}
}

?>

<script type='text/javascript'>
 function form_send1(a){
   
   var res=confirm("Do you want to confirm the booking?");
   if(res){
	   document.forms[a].submit();
   
   }  
   }
   function form_send2(a){
   
   var res=confirm("It's already booked!! Do you want to continue??");
   if(res){
	   document.forms[a].submit();
   
   }  
   }

 </script>	

</div>
</div>
	</div>
</section>
<footer class="site-footer row" role="contentinfo">
	<div class="container">
		<div class="pull-right"><ul id="menu-footer-menu" class="menu"><li id="menu-item-123" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-123"><a href="#">All Events</a></li>
<li id="menu-item-124" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-108 current_page_item menu-item-124"><a href="about.html">about</a></li>
</ul></div>		<p>
			<a href="#">Blog at IIT Patna</a>
			Theme: Evento Venue by <a rel="designer" class="designer-link" href="#">Platform @Btech14</a>.		</p>
		<p>
			<a class="wordpress-link" href="#">Webmail teamed up with Evento</a>
		</p>
	</div>
</footer>
</body></html>
